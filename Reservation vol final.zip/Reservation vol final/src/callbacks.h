#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>





void
on_ajouter_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierf_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_voirdispo_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
