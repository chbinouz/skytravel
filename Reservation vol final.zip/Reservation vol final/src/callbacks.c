#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"


void
on_ajouter_clicked               (GtkWidget       *objet,
                                   gpointer   user_data)
{
heberg h;
GtkWidget *spinbutton1;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2,*combobox1,*input6;
GtkWidget *espace;
GtkWidget *input0;

espace=lookup_widget(objet,"espace");
input1=lookup_widget(objet,"id");
input2=lookup_widget(objet,"periode");
input0=lookup_widget(objet,"spinbutton1");
h.etoiles=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1));
input3=lookup_widget(objet,"prixnuitee");
combobox2=lookup_widget(objet,"combobox2");
combobox1=lookup_widget(objet,"combobox1");
input6=lookup_widget(objet,"type_pension");

strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.periode,gtk_entry_get_text(GTK_ENTRY(input2)));
h.etoiles=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixnuitee,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.chambres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(h.nom_hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(h.type_pension,gtk_entry_get_text(GTK_ENTRY(input6)));
ajouter_heberg(h);


}




void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *espace;
GtkWidget *treeview1;


espace=lookup_widget(objet,"espace");


treeview1=lookup_widget(espace,"treeview1");

afficher_heberg(treeview1);
}






void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;

espace=lookup_widget(objet,"espace");

gtk_widget_destroy(espace);
espace=create_espace();
gtk_widget_show(espace);


}






void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;
char id1[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"id1");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimer_heberg(id1);

}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[3000];
GtkWidget *modifierheb;
modifierheb= create_modifierheb();
gtk_widget_show(modifierheb);

}


void
on_modifierf_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[3000];
heberg h1;
GtkWidget *modspinbutton;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2,*combobox1,*input6;
GtkWidget *modifier;
GtkWidget *input0;
GtkWidget *modcombobox;
GtkWidget *modcomboboxh;

modifier=lookup_widget(objet,"modifier");
input1=lookup_widget(objet,"modid");
input2=lookup_widget(objet,"modperiode");
input0=lookup_widget(objet,"modspinbutton");
h1.etoiles=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbutton));
input3=lookup_widget(objet,"modprix");
combobox2=lookup_widget(objet,"modcombobox");
combobox1=lookup_widget(objet,"modcomboboxh");
input6=lookup_widget(objet,"modpension");

strcpy(h1.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.periode,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.etoiles=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixnuitee,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.chambres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(h1.nom_hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(h1.type_pension,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier_heberg(h1);


}


void
on_voirdispo_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dep , *desti;
char depart[50][50];
char destination[50][50]; 
int n=0,i; 
dep=lookup_widget(objet,"combobox1");
desti=lookup_widget(objet,"combobox2");

n=remplir(depart,destination);
 if (n!=0) 
  {
    for (i=0 ;i<n ;i++)
       {
         gtk_combo_box_append_text (GTK_COMBO_BOX (dep),_(depart[i]));
          gtk_combo_box_append_text (GTK_COMBO_BOX (desti),_(destination[i]));
         
       }
  }

}


