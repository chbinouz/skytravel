#include <gtk/gtk.h>


void
on_buttonajouteradmin_clicked          (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_modierfieradmin_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_actualiseradmin_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprimeradmin_clicked              (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_actualiservalid_clicked             (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonsuppverif_clicked             (GtkWidget        *button,
                                        gpointer         user_data);


void
on_modifieradminfen_clicked            (GtkWidget     *objet_graphique,
                                        gpointer         user_data);
