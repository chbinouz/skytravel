#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"admin.h"


void
on_buttonajouteradmin_clicked          (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
admin s;
GtkWidget *nom1;
GtkWidget *cin1;
GtkWidget *mdp1;
GtkWidget *mail1;
GtkWidget *adresse1;
GtkWidget *combobox1;
GtkWidget *Jour;

GtkWidget *Annee;
GtkWidget *mois;
int r,w;
GtkWidget *output1;
output1=lookup_widget(objet_graphique,"labelcin");

GtkWidget *output2;
output2=lookup_widget(objet_graphique,"labelajout");

GtkWidget *output3;
output3=lookup_widget(objet_graphique,"labelmail");

nom1=lookup_widget(objet_graphique,"nomajou");
cin1=lookup_widget(objet_graphique,"cinajout");
mdp1=lookup_widget(objet_graphique,"mdpajou");
mail1=lookup_widget(objet_graphique,"mailajou");
adresse1=lookup_widget(objet_graphique,"adresseajout");
combobox1=lookup_widget(objet_graphique,"comboboxaj");
Jour=lookup_widget(objet_graphique,"spinbuttonaj");
Annee=lookup_widget(objet_graphique,"spinbutton2");
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(s.cin,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(s.mdp,gtk_entry_get_text(GTK_ENTRY(mdp1)));
strcpy(s.mail,gtk_entry_get_text(GTK_ENTRY(mail1)));
strcpy(s.adresse,gtk_entry_get_text(GTK_ENTRY(adresse1)));


s.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
s.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
strcpy(s.dt.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));


if (strlen(s.cin)==8 && strstr(s.mail,"@")){
ajouter_admin(s);
gtk_label_set_text(GTK_LABEL(output2),"compte ajouté");
gtk_label_set_text(GTK_LABEL(output1),"   ");
gtk_label_set_text(GTK_LABEL(output3),"   ");
}
else if (strlen(s.cin)!=8){
gtk_label_set_text(GTK_LABEL(output1),"inserez 8 chiffres");
gtk_label_set_text(GTK_LABEL(output2),"   ");

}

else if (strstr(s.mail,"@")!=1){
gtk_label_set_text(GTK_LABEL(output2),"    ");
gtk_label_set_text(GTK_LABEL(output1),"    ");
gtk_label_set_text(GTK_LABEL(output3),"xxx@xxx.xx");


}




}


void
on_modierfieradmin_clicked             (GtkWidget        *button,
                                        gpointer         user_data)
{
GtkWidget *modifieradmin;
modifieradmin = create_modifieradmin ();
  gtk_widget_show (modifieradmin);

}


void
on_actualiseradmin_clicked             (GtkWidget      *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *admin;
GtkWidget *output;

output=lookup_widget(button,"labelactualiser");
admin=lookup_widget(button,"admin");
treeview1=lookup_widget(admin,"treeview1");

afficher_ad(treeview1);

}


void
on_supprimeradmin_clicked              (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *output;
int r;
char nom[50];
input=lookup_widget(objet_graphique,"entry6");
output=lookup_widget(objet_graphique,"labelactualiser");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input)));
r=supprimer_adm(nom);
if (r==1){
gtk_label_set_text(GTK_LABEL(output),"compte supprimé");

}
else {
gtk_label_set_text(GTK_LABEL(output),"compte non trouvé");
}

}


void
on_actualiservalid_clicked             (GtkWidget        *button,
                                        gpointer         user_data)
{

}


void
on_buttonsuppverif_clicked             (GtkWidget       *button,
                                        gpointer         user_data)
{

}

void
on_modifieradminfen_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
admin s;
GtkWidget *nom1;
GtkWidget *cin1;
GtkWidget *mdp1;
GtkWidget *mail1;
GtkWidget *adresse1;
GtkWidget *combobox1;
GtkWidget *Jour;

GtkWidget *Annee;
GtkWidget *mois;

GtkWidget *output1;
output1=lookup_widget(objet_graphique,"labelmailmod");

GtkWidget *output2;
output2=lookup_widget(objet_graphique,"labelmod");

nom1=lookup_widget(objet_graphique,"nommod");
cin1=lookup_widget(objet_graphique,"cinmod");
mdp1=lookup_widget(objet_graphique,"mdpmod");
mail1=lookup_widget(objet_graphique,"mailmod");
adresse1=lookup_widget(objet_graphique,"adressemod");
combobox1=lookup_widget(objet_graphique,"comboboxmod");
Jour=lookup_widget(objet_graphique,"spinbuttonmod");
Annee=lookup_widget(objet_graphique,"spinbuttonmod1");
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(s.cin,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(s.mdp,gtk_entry_get_text(GTK_ENTRY(mdp1)));
strcpy(s.mail,gtk_entry_get_text(GTK_ENTRY(mail1)));
strcpy(s.adresse,gtk_entry_get_text(GTK_ENTRY(adresse1)));


s.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
s.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
strcpy(s.dt.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

if (strstr(s.mail,"@")){
modifier_a(s);
gtk_label_set_text(GTK_LABEL(output2),"compte modifié");
gtk_label_set_text(GTK_LABEL(output1),"   ");}

else if (strstr(s.mail,"@")==0){
gtk_label_set_text(GTK_LABEL(output2),"    ");
gtk_label_set_text(GTK_LABEL(output1),"xxx@xxx.xx");}




}

