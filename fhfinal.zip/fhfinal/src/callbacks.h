#include <gtk/gtk.h>


void
on_FHenvoyer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHmodifier_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHafficher_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHlirerec_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHsupprimer_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHRetourAjouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHconfirmer_modification_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_repondre_rec_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouter_rep_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_consulter_rep_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_lire_rep1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHretour_cl_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHretour_ag_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
