#include <gtk/gtk.h>
typedef struct
{
int jour;
int mois;
int annee;
}Date;

typedef struct
{

char cin[20];
Date dt_rec;
char objet[30];
char text[1000];
}ReclamationClient;

void ajouter_reclamation(ReclamationClient rc);
void afficher_reclamation(GtkWidget *liste);
void lire_reclamation(char cin1[],char text1[]);
void supprimer_reclamation(char cin[]);
void supprimer_Treclamation(char cin[]);
void modifier_text(ReclamationClient mod);
void saySuccesAjout(char FHsortie1[]);
void saySuccesModifier(char FHsortie2[]);
void saySuccesSupprimer(char FHsortiesup[]);
void ajouter_reponse(char cin[],char rep[]);
void lire_reponse(char cin1[],char rep1[]);
void supprimer_Trep(char cin[]);
			


