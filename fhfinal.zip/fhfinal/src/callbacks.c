#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "reclamation.h"
#include <string.h>


void
on_FHenvoyer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Jour; // spinbutton pour le choix du jour
GtkWidget *Mois; // spinbutton pour le choix du mois
GtkWidget *Annee; // spinbutton pour le choix de l'annee
GtkWidget *Combobox1; // combobox pour le choix de l'objet
GtkWidget *input3 ; //id
GtkWidget *input4 ; //text
GtkWidget *window1;
GtkWidget *output;

// associer les objets avec des variables

input3 = lookup_widget(objet_graphique, "FHentrycin") ;
input4 = lookup_widget(objet_graphique, "FHentrytext") ;
Jour=lookup_widget(objet_graphique, "FHjour");
Mois=lookup_widget(objet_graphique, "FHmois");
Annee=lookup_widget(objet_graphique, "FHannee");
Combobox1=lookup_widget(objet_graphique, "FHcombobox1");
output=lookup_widget(objet_graphique,"FHsuccessajout");


char cin[20];
char objet[30];
char text[1000];
char FHsortie1[200];
Date dt_rec;
ReclamationClient rc;
/* récuperer les valeurs des entrée en utilisant la fonction gtk_entry_get_text qui retourne la chaine choisie par l'utilisateur */

strcpy(rc.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(rc.text,gtk_entry_get_text(GTK_ENTRY(input4)));


/* récuperer les valeurs des spins buttons en utilisant la fonction gtk_spin_button_get_value_as_int qui retourne l'entier choisie par l'utilisateur */

rc.dt_rec.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
rc.dt_rec.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
rc.dt_rec.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));

/* recuperer les valeurs des comboboxs en utilisant la fonction gtk_combo_box_get_active_text qui retourne la chaine de caractere choisie par l'utilisateur */

strcpy(rc.objet,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
ajouter_reclamation(rc);
saySuccesAjout(FHsortie1);
gtk_label_set_text(GTK_LABEL(output),FHsortie1);

}


void
on_FHmodifier_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow1;
GtkWidget *FHwindow3;
FHwindow3 = create_FHwindow3 ();
  gtk_widget_show (FHwindow3);
FHwindow1=lookup_widget(objet_graphique,"FHwindow1");
gtk_widget_destroy(FHwindow1);
}


void
on_FHafficher_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow2;
GtkWidget *FHtreeview1;


FHwindow2=lookup_widget(objet_graphique,"FHwindow2");
gtk_widget_destroy(FHwindow2);
FHwindow2=lookup_widget(objet_graphique,"FHwindow2");
FHwindow2=create_FHwindow2();
gtk_widget_show(FHwindow2);

FHtreeview1=lookup_widget(FHwindow2,"FHtreeview1");

afficher_reclamation(FHtreeview1);
}


void
on_FHlirerec_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ReclamationClient rc;

GtkWidget *input ;
GtkWidget *output ;
char cin1[20];
char cin[20];
char text1[1000];
input=lookup_widget(objet_graphique,"FHentrylire") ; 
output=lookup_widget(objet_graphique,"showrec") ;
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(input)));
lire_reclamation(cin1,text1);
gtk_label_set_text(GTK_LABEL(output),text1);
}


void
on_FHsupprimer_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHtreeview1;
GtkWidget *FHwindow2;
GtkWidget *input;
GtkWidget *FHoutputsup;
char cin[50];
char cin1[50];
char FHsortiesup[200];
input=lookup_widget(objet_graphique,"FHentrylire");
FHoutputsup=lookup_widget(objet_graphique,"FHsucessupprimer");

strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_reclamation(cin);
supprimer_Treclamation(cin);
supprimer_Trep(cin1);
saySuccesSupprimer(FHsortiesup);
gtk_label_set_text(GTK_LABEL(FHoutputsup),FHsortiesup);
}


void
on_FHRetourAjouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow1;
GtkWidget *FHwindow3;

FHwindow1=lookup_widget(objet_graphique,"FHwindow1");
FHwindow1=create_FHwindow1();
gtk_widget_show(FHwindow1);
FHwindow3=lookup_widget(objet_graphique,"FHwindow3");
gtk_widget_destroy(FHwindow3);
}


void
on_FHconfirmer_modification_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Jour; // spinbutton pour le choix du jour
GtkWidget *Mois; // spinbutton pour le choix du mois
GtkWidget *Annee; // spinbutton pour le choix de l'annee
GtkWidget *Combobox1; // combobox pour le choix de l'objet

GtkWidget *input3 ; //id
GtkWidget *input4 ; //text
GtkWidget *window1;
GtkWidget *output;

char cin[20];
char objet[30];
char text[1000];
char FHsortie2[200];
Date dt_rec;
ReclamationClient rc;

// associer les objets avec des variables

input3 = lookup_widget(objet_graphique, "FHentrycinmod") ;
input4 = lookup_widget(objet_graphique, "FHentrytextmod") ;
Jour=lookup_widget(objet_graphique, "FHjourmod");
Mois=lookup_widget(objet_graphique, "FHmoismod");
Annee=lookup_widget(objet_graphique, "FHanneemod");
Combobox1=lookup_widget(objet_graphique, "FHcombobox1mod");
output=lookup_widget(objet_graphique,"FHsuccessmodifier");


/* récuperer les valeurs des entrée en utilisant la fonction gtk_entry_get_text qui retourne la chaine choisie par l'utilisateur */

strcpy(rc.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(rc.text,gtk_entry_get_text(GTK_ENTRY(input4)));


/* récuperer les valeurs des spins buttons en utilisant la fonction gtk_spin_button_get_value_as_int qui retourne l'entier choisie par l'utilisateur */

rc.dt_rec.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
rc.dt_rec.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
rc.dt_rec.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));

/* recuperer les valeurs des comboboxs en utilisant la fonction gtk_combo_box_get_active_text qui retourne la chaine de caractere choisie par l'utilisateur */

strcpy(rc.objet,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
modifier_reclamation(rc);
modifier_text(rc);
saySuccesModifier(FHsortie2);
gtk_label_set_text(GTK_LABEL(output),FHsortie2);
}


void
on_repondre_rec_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow4;
GtkWidget *FHwindow2;
FHwindow4=lookup_widget(objet_graphique,"FHwindow4");
FHwindow4 = create_FHwindow4();
gtk_widget_show(FHwindow4);
FHwindow2=lookup_widget(objet_graphique,"FHwindow2");
gtk_widget_destroy(FHwindow2);
}


void
on_ajouter_rep_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input5,*input4;

GtkWidget *FHwindow4;
GtkWidget *output1;

char cin[100];
char rep[100];

FHwindow4=lookup_widget(objet_graphique,"FHwindow4");
input5=lookup_widget(objet_graphique,"NDentrycinrep");

input4=lookup_widget(objet_graphique,"NDentryrep");

strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(rep,gtk_entry_get_text(GTK_ENTRY(input4)));

ajouter_reponse(cin,rep);
output1=lookup_widget(objet_graphique,"NDaffichereponse");
gtk_label_set_text(GTK_LABEL(output1),"votre réponse a été envoyer avec succés");
}


void
on_consulter_rep_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{GtkWidget *FHwindow1;
GtkWidget *FHwindow5;
FHwindow5=lookup_widget(objet_graphique,"FHwindow5");
FHwindow5= create_FHwindow5();
gtk_widget_show(FHwindow5);
FHwindow1=lookup_widget(objet_graphique,"FHwindow1");
gtk_widget_destroy(FHwindow1);

}


void
on_lire_rep1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input ;
GtkWidget *output ;

char cin1[20];
char cin[20];
char rep1[1000];

input=lookup_widget(objet_graphique,"NDentrycinvoir") ; 
output=lookup_widget(objet_graphique,"show_rep") ;
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(input)));

lire_reponse(cin1,rep1);

gtk_label_set_text(GTK_LABEL(output),rep1);
}


void
on_FHretour_cl_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow1;
GtkWidget *FHwindow5;

FHwindow1=lookup_widget(objet_graphique,"FHwindow1");
FHwindow1=create_FHwindow1();
gtk_widget_show(FHwindow1);
FHwindow5=lookup_widget(objet_graphique,"FHwindow5");
gtk_widget_destroy(FHwindow5);
}


void
on_FHretour_ag_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow2;
GtkWidget *FHwindow4;

FHwindow2=lookup_widget(objet_graphique,"FHwindow2");
FHwindow2=create_FHwindow2();
gtk_widget_show(FHwindow2);
FHwindow4=lookup_widget(objet_graphique,"FHwindow4");
gtk_widget_destroy(FHwindow4);
}

