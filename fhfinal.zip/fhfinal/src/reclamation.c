#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "reclamation.h"
#include <gtk/gtk.h>
#include <math.h>


enum
{
	
	CIN,
	JJ,
	MM,
	AA,
	OBJET,
	COLUMNS
};

void afficher_reclamation(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

ReclamationClient rc;

char cin[20];
Date dt_rec;
char objet[30];


store =NULL;

FILE* f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

	//renderer=gtk_cell_renderer_text_new();
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("dt_rec.jour",renderer,"text",JJ,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("dt_rec.mois",renderer,"text",MM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("dt_rec.annee",renderer,"text",AA,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("objet",renderer,"text",OBJET,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);


	f=fopen("reclamation.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("reclamation.txt","a+");
		while(fscanf(f,"%s %d %d %d %s \n",rc.cin,&rc.dt_rec.jour,&rc.dt_rec.mois,&rc.dt_rec.annee,rc.objet)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,CIN,rc.cin,JJ,rc.dt_rec.jour,MM,rc.dt_rec.mois,AA,rc.dt_rec.annee,OBJET,rc.objet,-1);
		}
	   fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	}
	



}
}

void ajouter_reclamation(ReclamationClient rc)
{
	FILE* f=fopen("reclamation.txt","a");
	if(f!=NULL)
	{
	fprintf(f," %s %d %d %d %s \n",rc.cin,rc.dt_rec.jour,rc.dt_rec.mois,rc.dt_rec.annee,rc.objet);
	fclose(f);
	}
	
	FILE* t=fopen("text.txt","a");
	if(t!=NULL)
	{
	fprintf(t,"%s %s \n",rc.cin,rc.text);
	fclose(t);
	}
}

void lire_reclamation(char cin1[],char text1[])
{

ReclamationClient rc;


    FILE *f,*ftemp;
    f=fopen("text.txt","r");
if(f!=NULL)  {
   
         while(fscanf(f,"%s %[^\n]s",rc.cin,rc.text)!=EOF)
        { if(strcmp(rc.cin,cin1)==0)
        
            strcpy(text1,rc.text);
        
    }
   
    fclose(f);
   } 
}
	
void supprimer_reclamation(char cin[]){
ReclamationClient sup;
FILE *f_sup;
FILE *f_sup1;
int r;
f_sup=fopen("reclamation.txt","r");
f_sup1=fopen("reclamation1.txt","w");
if (f_sup!=NULL){
    if(f_sup1!=NULL){
while(fscanf(f_sup," %s %d %d %d %s \n",sup.cin,&sup.dt_rec.jour,&sup.dt_rec.mois,&sup.dt_rec.annee,sup.objet)!=EOF) {
    if(strcmp(cin,sup.cin)!=0){
        fprintf(f_sup1," %s %d %d %d %s \n",sup.cin,sup.dt_rec.jour,sup.dt_rec.mois,sup.dt_rec.annee,sup.objet);
        r=1;
    }
}fclose(f_sup1);
    }
    fclose(f_sup);
}


if (r){
	remove ("reclamation.txt");
	rename ("reclamation1.txt","reclamation.txt");
	}

}

void supprimer_Treclamation(char cin[]){
ReclamationClient sup;
FILE *f_sup;
FILE *f_sup1;
int r;
f_sup=fopen("text.txt","r");
f_sup1=fopen("text1.txt","w");
if (f_sup!=NULL){
    if(f_sup1!=NULL){
while(fscanf(f_sup,"%s %[^\n]s \n",sup.cin,sup.text)!=EOF) {
    if(strcmp(cin,sup.cin)!=0){
        fprintf(f_sup1,"%s %s \n",sup.cin,sup.text);
        r=1;
    }
}
    }
    fclose(f_sup1);
}

fclose(f_sup);
if (r){
	remove ("text.txt");
	rename ("text1.txt","text.txt");
	}

}
void modifier_reclamation(ReclamationClient mod)
{
ReclamationClient mod1; 
    FILE * f_admin;
    FILE *f_admin1;
f_admin=fopen("reclamation.txt","r");
f_admin1=fopen("reclamation2.txt","w");
if(f_admin!=NULL){
    if(f_admin1!=NULL){
while (fscanf(f_admin," %s %d %d %d %s \n",mod1.cin,&mod1.dt_rec.jour,&mod1.dt_rec.mois,&mod1.dt_rec.annee,mod1.objet)!=EOF) {
            if  (strcmp(mod.cin,mod1.cin)!=0){
 fprintf(f_admin1,"%s %d %d %d %s \n",mod1.cin,mod1.dt_rec.jour,mod1.dt_rec.mois,mod1.dt_rec.annee,mod1.objet);
            }
            else {
   fprintf(f_admin1," %s %d %d %d %s \n",mod.cin,mod.dt_rec.jour,mod.dt_rec.mois,mod.dt_rec.annee,mod.objet);
            }
        }
    }
}
fclose(f_admin1);
fclose(f_admin);
remove("reclamation.txt");
rename("reclamation2.txt","reclamation.txt");
}
void modifier_text(ReclamationClient mod)
{
ReclamationClient mod1; 
    FILE * f_admin;
    FILE *f_admin1;
f_admin=fopen("text.txt","r");
f_admin1=fopen("text2.txt","w");
if(f_admin!=NULL){
    if(f_admin1!=NULL){
while (fscanf(f_admin,"%s %[^\n]s \n",mod1.cin,mod1.text)!=EOF) {
            if  (strcmp(mod.cin,mod1.cin)!=0){
 fprintf(f_admin1,"%s %s \n",mod1.cin,mod1.text);
            }
            else {
   fprintf(f_admin1,"%s %s \n",mod.cin,mod.text);
            }
        }
    }
}
fclose(f_admin1);
fclose(f_admin);
remove("text.txt");
rename("text2.txt","text.txt");
}
void saySuccesAjout(char FHsortie1[])
{
     strcpy(FHsortie1,"Votre reclamation a été ajoutée!");
}

void saySuccesModifier(char FHsortie2[])
{
     strcpy(FHsortie2,"Votre modification a été effectuée!");
}

void saySuccesSupprimer(char FHsortiesup[])
{
     strcpy(FHsortiesup,"La réclamation a été supprimée!");
}
void ajouter_reponse(char cin[],char rep[])
{

 FILE *f;
 f=fopen("reponse_reclamation.txt","a");
 if(f!=NULL)
 {
 fprintf(f,"%s %s \n",cin,rep);

 }
 fclose(f);
}

void lire_reponse(char cin1[],char rep1[])
{
char cin[20];
char rep[1000];
    FILE *f,*ftemp;
    f=fopen("reponse_reclamation.txt","r");
if(f!=NULL)  {
   
         while(fscanf(f,"%s %[^\n]s",cin,rep)!=EOF)
        { if(strcmp(cin,cin1)==0)
        
            strcpy(rep1,rep);
        
    }
   
    fclose(f);
   } 
}


void supprimer_Trep(char cin1[]){

FILE *f_sup;
FILE *f_sup1;
int r;
char cin[50],rep[1000];
f_sup=fopen("reponse_reclamation.txt","r");
f_sup1=fopen("reponse_reclamation1.txt","w");
if (f_sup!=NULL){
    if(f_sup1!=NULL){
while(fscanf(f_sup,"%s %[^\n]s \n",cin,rep)!=EOF) {
    if(strcmp(cin1,cin)!=0){
        fprintf(f_sup1,"%s %s \n",cin,rep);
        r=1;
    }
}
    }
    fclose(f_sup1);
}

fclose(f_sup);
if (r){
	remove ("reponse_reclamation.txt");
	rename ("reponse_reclamation1.txt","reponse_reclamation.txt");
	}

}
