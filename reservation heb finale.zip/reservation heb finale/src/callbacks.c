#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"


void
on_ajouter_clicked               (GtkWidget       *objet,
                                   gpointer   user_data)
{
rheberg h;
GtkWidget *spinbutton1;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2,*combobox1,*input6;
GtkWidget *espace;
GtkWidget *input0;

espace=lookup_widget(objet,"espaceam");
input1=lookup_widget(objet,"idam");
input2=lookup_widget(objet,"periodeam");
input0=lookup_widget(objet,"spinbutton1am");
h.etoilesam=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1));
input3=lookup_widget(objet,"prixnuiteeam");
combobox2=lookup_widget(objet,"combobox2am");
combobox1=lookup_widget(objet,"combobox1am");
input6=lookup_widget(objet,"type_pensionam");

strcpy(h.idam,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.periodeam,gtk_entry_get_text(GTK_ENTRY(input2)));
h.etoilesam=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixnuiteeam,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.chambresam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(h.nom_hotelam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(h.type_pensionam,gtk_entry_get_text(GTK_ENTRY(input6)));
ajouter_rheberg(h);


}




void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *espace;
GtkWidget *treeview1am;


espace=lookup_widget(objet,"espaceam");


treeview1am=lookup_widget(espace,"treeview1am");

afficher_rheberg(treeview1am);
}






void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espaceam;

espaceam=lookup_widget(objet,"espaceam");

gtk_widget_destroy(espaceam);
espaceam=create_espaceam();
gtk_widget_show(espaceam);


}






void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espaceam;
char idam1[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"idam1");
strcpy(idam1,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimer_rheberg(idam1);

}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
char idam1[3000];
GtkWidget *modifierheb;
modifierheb= create_modifierheb();
gtk_widget_show(modifierheb);

}


void
on_modifierf_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char idam1[3000];
rheberg h1;
GtkWidget *modspinbuttonam;
GtkWidget *etoilesam;
GtkWidget *input1,*input2,*input3,*combobox2am,*combobox1am,*input6;
GtkWidget *modifier;
GtkWidget *input0;
GtkWidget *modcomboboxam;
GtkWidget *modcomboboxham;

modifier=lookup_widget(objet,"modifieram");
input1=lookup_widget(objet,"modidam");
input2=lookup_widget(objet,"modperiodeam");
input0=lookup_widget(objet,"modspinbuttonam");
h1.etoilesam=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbuttonam));
input3=lookup_widget(objet,"modprixam");
combobox2am=lookup_widget(objet,"modcomboboxam");
combobox1am=lookup_widget(objet,"modcomboboxham");
input6=lookup_widget(objet,"modpensionam");

strcpy(h1.idam,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.periodeam,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.etoilesam=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixnuiteeam,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.chambresam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2am)));
strcpy(h1.nom_hotelam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1am)));
strcpy(h1.type_pensionam,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier_rheberg(h1);


}


void
on_buttondispo_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *hot , *cham;
char hotel[50][50];
char chambre[50][50]; 
int n=0,i; 
hot=lookup_widget(objet,"combobox1am");
cham=lookup_widget(objet,"combobox2am");

n=remplir(hotel,chambre);
 if (n!=0) 
  {
    for (i=0 ;i<n ;i++)
       {
         gtk_combo_box_append_text (GTK_COMBO_BOX (hot),_(hotel[i]));
          gtk_combo_box_append_text (GTK_COMBO_BOX (cham),_(chambre[i]));
         
       }
  }

}

