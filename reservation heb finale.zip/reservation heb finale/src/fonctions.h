#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>

typedef struct
{
char idam[2000];
char periodeam[20];
int etoilesam;
char prixnuiteeam[30];
char chambresam[30];
char nom_hotelam[20];
char type_pensionam[1000];

}rheberg;

void ajouter_rheberg(rheberg h);
void afficher_rheberg(GtkWidget *liste);
void supprimer_rheberg(char idam1[]);
void modifier_rheberg(rheberg h);
int remplir(char hotelam[][50] , char chambream[][50]) ; 
