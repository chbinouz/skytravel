#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonctions.h"


void
on_ajouter_clicked               (GtkWidget       *objet,
                                   gpointer   user_data)
{
heberg h;
GtkWidget *spinbutton1;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2,*combobox1,*input6;
GtkWidget *espace;
GtkWidget *input0;
GtkWidget *output,*output1,*output2,*output3,*output4;
char empty[]="\0";
GtkWidget *felicitationsheb;
output=lookup_widget(objet,"erreur");
output1=lookup_widget(objet,"erreur1");
output2=lookup_widget(objet,"erreur2");
output3=lookup_widget(objet,"erreur3");
output4=lookup_widget(objet,"msger");
espace=lookup_widget(objet,"espace");
input1=lookup_widget(objet,"id");
input2=lookup_widget(objet,"periode");
input0=lookup_widget(objet,"spinbutton1");
h.etoiles=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1));
input3=lookup_widget(objet,"prixnuitee");
combobox2=lookup_widget(objet,"combobox2");
combobox1=lookup_widget(objet,"combobox1");
input6=lookup_widget(objet,"type_pension");

strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.periode,gtk_entry_get_text(GTK_ENTRY(input2)));
h.etoiles=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixnuitee,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.chambres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(h.nom_hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(h.type_pension,gtk_entry_get_text(GTK_ENTRY(input6)));
if(strcmp(h.id,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}
else if(strcmp(h.periode,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output1),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}
else if(strcmp(h.prixnuitee,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output2),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}
else if(strcmp(h.type_pension,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output3),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}

else
{
ajouter_heberg(h);
felicitationsheb=lookup_widget(objet,"felicitationsheb");
felicitationsheb=create_felicitationsheb();
gtk_widget_show(felicitationsheb);
}

}




void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *espace;
GtkWidget *treeview1;


espace=lookup_widget(objet,"espace");


treeview1=lookup_widget(espace,"treeview1");

afficher_heberg(treeview1);
}






void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;

espace=lookup_widget(objet,"espace");

gtk_widget_destroy(espace);
espace=create_espace();
gtk_widget_show(espace);


}






void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *felicitationssuph;
GtkWidget *espace;
char id1[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"id1");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimer_heberg(id1);
{
felicitationssuph=lookup_widget(objet,"felicitationssuph");
felicitationssuph=create_felicitationssuph();
gtk_widget_show(felicitationssuph);
}
}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[3000];
GtkWidget *modifierheb;
modifierheb= create_modifierheb();
gtk_widget_show(modifierheb);

}


void
on_modifierf_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[3000];
char idd[3000];
heberg h1;
GtkWidget *modspinbutton;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2,*combobox1,*input6;
GtkWidget *modifier;
GtkWidget *input0;
GtkWidget *modcombobox;
GtkWidget *modcomboboxh;
GtkWidget *felicitationsmodh;

modifier=lookup_widget(objet,"modifier");
input1=lookup_widget(objet,"modid");
input2=lookup_widget(objet,"modperiode");
input0=lookup_widget(objet,"modspinbutton");
h1.etoiles=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbutton));
input3=lookup_widget(objet,"modprix");
combobox2=lookup_widget(objet,"modcombobox");
combobox1=lookup_widget(objet,"modcomboboxh");
input6=lookup_widget(objet,"modpension");

strcpy(h1.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.periode,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.etoiles=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixnuitee,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.chambres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(h1.nom_hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(h1.type_pension,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier_heberg(h1);
{
felicitationsmodh=lookup_widget(objet,"felicitationsmodh");
felicitationsmodh=create_felicitationsmodh();
gtk_widget_show(felicitationsmodh);
}


}


void
on_rechercherhebm_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
heberg h;
GtkWidget *modifierheb;
GtkWidget *input1,*output1,*output2,*output4,*output5;

char idd[3000];
char modperiode[300];
char modprix[300];
char modpension[300];



output1=lookup_widget(objet,"modid");
output2=lookup_widget(objet,"modperiode");
output4=lookup_widget(objet,"modprix");
output5=lookup_widget(objet,"modpension");
input1=lookup_widget(objet,"idd");
strcpy(idd,gtk_entry_get_text(GTK_ENTRY(input1)));

FILE *f;
	f=fopen("utilisateur.txt","r");
	if(f!=NULL)
{
while(fscanf(f,"%s %s %d %s %s %s %s  \n",h.id,h.periode,&h.etoiles,h.prixnuitee,h.chambres,h.nom_hotel,h.type_pension)!=EOF)
{
	if (strcmp(h.id,idd)==0)
{
gtk_entry_set_text (GTK_ENTRY (output1),h.id);
gtk_entry_set_text (GTK_ENTRY (output2),h.periode);
gtk_entry_set_text (GTK_ENTRY (output4),h.prixnuitee);
gtk_entry_set_text (GTK_ENTRY (output5),h.type_pension);
}
}
}
fclose(f);

}

