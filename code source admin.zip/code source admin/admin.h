#ifndef ADMIN_H_INCLUDED
#define ADMIN_H_INCLUDED
typedef struct date{
int jour;
char mois[30];
int annee;}date;

typedef struct admin {
char nom[30];
char cin[30];
date dt;
char mail[30];
char adresse[30];
char mdp[30];
}admin;


void ajouter_admin(admin ajo);

void chercher_ad(char cin1[]);

void modifier_admin(admin mod);

void afficher_admin();

void supprimer_adm(char cin[]);


#endif // ADMIN_H_INCLUDED
