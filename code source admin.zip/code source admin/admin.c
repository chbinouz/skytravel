#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"admin.h"

void ajouter_admin(admin ajo){
    int n=2;
FILE * f_admin;
f_admin=fopen("employ�s.txt","a+");
if(f_admin!=NULL){
    fprintf(f_admin,"%s %s %d %d/%s/%d %s %s %s \n",ajo.nom,ajo.cin,n,ajo.dt.jour,ajo.dt.mois,ajo.dt.annee,ajo.mail,ajo.adresse,ajo.mdp);
}
fclose(f_admin);
}

void chercher_ad(char cin1[]){
    admin mod1;
int n;
char dat[30];
    FILE * f_admin;
f_admin=fopen("employ�s.txt","r");
if (f_admin!=NULL) {
    while (fscanf(f_admin,"%s %s %d %s %s %s %s",mod1.nom,mod1.cin,&n,dat,mod1.mail,mod1.adresse,mod1.mdp)!=EOF){
        fscanf(f_admin,"%s %s",mod1.nom,mod1.cin);
        if (strcmp(mod1.cin,cin1)==0){
            printf("%s de cin: %s",mod1.nom,cin1);
            break;

        }
        else {
            printf("identifiant cherch�e non trouv�e\n");

            break;
        }
    }
}
}

void modifier_admin(admin mod){
int n;
char dat[30];
    admin mod1;
    FILE * f_admin;
    FILE *f_admin1;
f_admin=fopen("employ�s.txt","r");
f_admin1=fopen("employ�s2.txt","w");
if(f_admin!=NULL){
    if(f_admin1!=NULL){
        while (fscanf(f_admin,"%s %s %d %s %s %s %s",mod1.nom,mod1.cin,&n,dat,mod1.mail,mod1.adresse,mod1.mdp)!=EOF){
            if  (strcmp(mod.cin,mod1.cin)!=0){
                fprintf(f_admin1,"%s %s %d %d/%s/%d %s %s %s \n",mod1.nom,mod1.cin,n,mod1.dt.jour,mod1.dt.mois,mod1.dt.annee,mod1.mail,mod1.adresse,mod1.mdp);
            }
            else {
                fprintf(f_admin1,"%s %s %d %d/%s/%d %s %s %s \n",mod.nom,mod.cin,n,mod.dt.jour,mod.dt.mois,mod.dt.annee,mod.mail,mod.adresse,mod.mdp);
            }
        }
    }
}
fclose(f_admin1);
fclose(f_admin);
remove("employ�s.txt");
rename("employ�s2.txt","employ�s.txt");
}

void afficher_admin(){

char chaine[1000] = "";
FILE * f_aff=NULL;
f_aff= fopen ("employ�s.txt","r");
if (f_aff != NULL)
    {
        do
        {
            fgets(chaine, 1000, f_aff);
        printf("%s", chaine);

        }while (fgets(chaine, 1000, f_aff) != NULL); // On affiche la cha�ne

        fclose(f_aff);

}
}



void supprimer_adm(char cin[]){
admin sup;
FILE *f_sup;
FILE *f_sup1;
int r;
int n;
char dat[30];
f_sup=fopen("employ�s.txt","r");
f_sup1=fopen("employ�s1.txt","w");
if (f_sup!=NULL){
    if(f_sup1!=NULL){
while(fscanf(f_sup,"%s %s %d %s %s %s %s",sup.nom,sup.cin,&n,dat,sup.mail,sup.adresse,sup.mdp)!=EOF ) {
    if(strcmp(cin,sup.cin)!=0){
        fprintf(f_sup1,"%s %s %d %d/%s/%d %s %s %s \n",sup.nom,sup.cin,n,sup.dt.jour,sup.dt.mois,sup.dt.annee,sup.mail,sup.adresse,sup.mdp);
        r=1;
    }
}
    }
    fclose(f_sup1);
}

fclose(f_sup);
if (r){
	remove ("employ�s.txt");
	rename ("employ�s1.txt","employ�s.txt");
	}

}
