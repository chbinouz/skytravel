#include <stdio.h>
#include <stdlib.h>
#include"admin.h"
#include<string.h>
int main()
{  admin aj,md1;
char cin[30];
    int x=8;

     while (x!=9){
    printf(" 1 pour ajouter \n 2 pour modifier \n 3 pour afficher\n 4 pour supprimer \n 5 pour chercher \n 9 pour quitter \n");
    scanf("%d",&x);

    switch (x) {
case 1:


    printf("nom\n");
    fflush(stdin);
    scanf("%s",aj.nom);
    printf("cin\n");
     fflush(stdin);
    scanf("%s",aj.cin);

    printf("jour\n");
     fflush(stdin);
    scanf("%d",&aj.dt.jour);

    printf("mois\n");
     fflush(stdin);
    scanf("%s",aj.dt.mois);

    printf("annee\n");
     fflush(stdin);
    scanf("%d",&aj.dt.annee);

    printf("mail\n");
     fflush(stdin);
    scanf("%s",aj.mail);
    printf("adresse\n");
     fflush(stdin);
    scanf("%s",aj.adresse);
    printf("mdp\n");
     fflush(stdin);
    scanf("%s",aj.mdp);
ajouter_admin(aj);
break;
case 2:

    printf("nom a modifier\n");
    scanf("%s %s %d %s %d %s %s %s",md1.nom,md1.cin,&md1.dt.jour,md1.dt.mois,&md1.dt.annee,md1.mail,md1.adresse,md1.mdp);
    modifier_admin(md1);
break;
case 3:

    afficher_admin();
    break;

case 4:
    printf("ecrivez le cin a supprimer\n ");
    scanf("%s",cin);
    supprimer_adm(cin);
break;
case 5:
    printf("ecrivez le cin a chercher\n ");
    scanf("%s",cin);
    chercher_ad(cin);

    }
}}
