#include <stdio.h>
#include <string.h>
#include "fonctionsa.h"
#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>
enum
{
	IDAM,
	PERIODEAM,
	ETOILESAM,
	PRIXNUITEEAM,
	CHAMBRESAM,
	NOM_HOTELAM,
	TYPE_PENSIONAM,
	COLUMNS
};

void ajouter_rheberg(rheberg h)
{

 FILE *f;
 f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","a+");
 if(f!=NULL)
 {
 fprintf(f,"%s %s %d %s %s %s %s  \n",h.idam,h.periodeam,h.etoilesam,h.prixnuiteeam,h.chambresam,h.nom_hotelam,h.type_pensionam);
 fclose(f);
 }

}

void afficher_rheberg(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char idam [3000];
char periodeam [30];
int  etoilesam;
char prixnuiteeam [30];
char chambresam [30];
char nom_hotelam [30];
char type_pensionam [3000];
store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("ID",renderer,"text",IDAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Periode",renderer,"text",PERIODEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Etoiles",renderer,"text",ETOILESAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Prix d'une nuitee",renderer,"text",PRIXNUITEEAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Chambres",renderer,"text",CHAMBRESAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nom hotel",renderer,"text",NOM_HOTELAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Type pension",renderer,"text",TYPE_PENSIONAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}
	
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","a+");
		while(fscanf(f,"%s %s %d %s %s %s %s  \n",idam,periodeam,&etoilesam,prixnuiteeam,chambresam,nom_hotelam,type_pensionam)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,IDAM,idam,PERIODEAM,periodeam,ETOILESAM,etoilesam,PRIXNUITEEAM,prixnuiteeam,CHAMBRESAM,chambresam,NOM_HOTELAM,nom_hotelam,TYPE_PENSIONAM,type_pensionam,-1);
		}
	   fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
void supprimer_rheberg(char idam1[]){
rheberg h;
FILE *f_h;
FILE *f_h1;

int r;
int n;
f_h=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","r");
f_h1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb1.txt","w");
if (f_h!=NULL){
    if(f_h1!=NULL){
while(fscanf(f_h,"%s %s %d %s %s %s %s",h.idam,h.periodeam,&h.etoilesam,h.prixnuiteeam,h.chambresam,h.nom_hotelam,h.type_pensionam)!=EOF ) {
    if(strcmp(idam1,h.idam)!=0){
        fprintf(f_h1,"%s %s %d %s %s %s %s \n",h.idam,h.periodeam,h.etoilesam,h.prixnuiteeam,h.chambresam,h.nom_hotelam,h.type_pensionam);
        r=1;
    }
}
    }
    fclose(f_h1);
}

fclose(f_h);
if (r){
	remove ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt");
	rename ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb1.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt");
	}

}
void modifier_rheberg(rheberg h){
int n=0;
char idam1[3000];

char modidam[2000];
char modperiodeam[20];
int  modetoilesam;
char modprixam[30];
char modchambresam[30];
char modnomam[20];
char modpensionam[1000];


    FILE *f_rheberg;
    FILE *f_rheberg1;
f_rheberg=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","r");
f_rheberg1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb2.txt","w");
if(f_rheberg!=NULL){
    if(f_rheberg1!=NULL){
while (fscanf(f_rheberg,"%s %s %d %s %s %s %s",modidam,modperiodeam,&modetoilesam,modprixam,modchambresam,modnomam,modpensionam,&n)!=EOF){
            if  (strcmp(h.idam,modidam)==0){
 fprintf(f_rheberg1,"%s %s %d %s %s %s %s \n",h.idam,h.periodeam,h.etoilesam,h.prixnuiteeam,h.chambresam,h.nom_hotelam,h.type_pensionam,n);
            }
            else {
   fprintf(f_rheberg1,"%s %s %d %s %s %s %s  \n",modidam,modperiodeam,modetoilesam,modprixam,modchambresam,modnomam,modpensionam,n);
            }
        }
    }
}
fclose(f_rheberg1);
fclose(f_rheberg);
remove("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb1.txt");
rename("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb2.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt");
}



int remplir(char hotel[][50] , char chambre[][50]) 
{

rheberg h ; 

int c=0 ; 


FILE *f ; 
f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %d %s %s %s %s \n",h.idam,&h.etoilesam,h.prixnuiteeam,h.chambresam,h.nom_hotelam,h.type_pensionam)!=EOF)
{

strcpy(hotel[c],h.nom_hotelam) ;
strcpy(chambre[c],h.chambresam) ; 
c++ ;
} 
}

fclose(f); 
return c ; 

}


