#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "admin.h"
#include "fonctions.h"
#include "reclamation.h"
#include "function.h"
#include "client.h"
#include "fonctionsv.h"
#include "fonctionsv1.h"
#include "fonctionsa.h"
#include "fonctions1.h"
#include <string.h>

void
on_buttonajouteradmin_clicked          (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
admin s;
GtkWidget *nom1;
GtkWidget *cin1;
GtkWidget *mdp1;
GtkWidget *mail1;
GtkWidget *adresse1;
GtkWidget *combobox1;
GtkWidget *Jour;

GtkWidget *Annee;
GtkWidget *mois;
int r,w;
GtkWidget *output1;
output1=lookup_widget(objet_graphique,"labelcin");

GtkWidget *output2;
output2=lookup_widget(objet_graphique,"labelajout");

GtkWidget *output3;
output3=lookup_widget(objet_graphique,"labelmail");

nom1=lookup_widget(objet_graphique,"nomajou");
cin1=lookup_widget(objet_graphique,"cinajout");
mdp1=lookup_widget(objet_graphique,"mdpajou");
mail1=lookup_widget(objet_graphique,"mailajou");
adresse1=lookup_widget(objet_graphique,"adresseajout");
combobox1=lookup_widget(objet_graphique,"comboboxaj");
Jour=lookup_widget(objet_graphique,"spinbuttonaj");
Annee=lookup_widget(objet_graphique,"spinbutton2");
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(s.cin,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(s.mdp,gtk_entry_get_text(GTK_ENTRY(mdp1)));
strcpy(s.mail,gtk_entry_get_text(GTK_ENTRY(mail1)));
strcpy(s.adresse,gtk_entry_get_text(GTK_ENTRY(adresse1)));


s.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
s.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
strcpy(s.dt.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));


if (strlen(s.cin)==8 && strstr(s.mail,"@")){
ajouter_admin(s);
gtk_label_set_text(GTK_LABEL(output2),"compte ajouté");
gtk_label_set_text(GTK_LABEL(output1),"   ");
gtk_label_set_text(GTK_LABEL(output3),"   ");
}
else if (strlen(s.cin)!=8){
gtk_label_set_text(GTK_LABEL(output1),"inserez 8 chiffres");
gtk_label_set_text(GTK_LABEL(output2),"   ");

}

else if (strstr(s.mail,"@")!=1){
gtk_label_set_text(GTK_LABEL(output2),"    ");
gtk_label_set_text(GTK_LABEL(output1),"    ");
gtk_label_set_text(GTK_LABEL(output3),"xxx@xxx.xx");


}
}


void
on_actualiseradmin_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *treeview1;
GtkWidget *admin;
GtkWidget *output;

output=lookup_widget(button,"labelactualiser");
admin=lookup_widget(button,"admin");
treeview1=lookup_widget(admin,"treeview1");

afficher_ad(treeview1);
gtk_label_set_text(GTK_LABEL(output),"   ");
}


void
on_supprimeradmin_clicked              (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input;
GtkWidget *output;
int r;
char nom[50];
input=lookup_widget(objet_graphique,"chbentry6");
output=lookup_widget(objet_graphique,"labelactualiser");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input)));
r=supprimer_adm(nom);
if (r==1){
gtk_label_set_text(GTK_LABEL(output),"compte supprimé");

}
else {
gtk_label_set_text(GTK_LABEL(output),"compte non trouvé");
}
}


void
on_modifieradmin_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *modifieradmin;
modifieradmin = create_modifieradmin ();
  gtk_widget_show (modifieradmin);
}


void
on_actualiserverif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *treeviewverif;
GtkWidget *admin;



admin=lookup_widget(objet,"admin");
treeviewverif=lookup_widget(admin,"treeviewverif");

afficher_client(treeviewverif);
}


void
on_suppverif_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input;

char cin4[30];



input=lookup_widget(objet,"entryverif");

strcpy(cin4,gtk_entry_get_text(GTK_ENTRY(input)));


supprimer(cin4);
supprimer1(cin4);

}


void
on_modifieradminfen_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
admin s;
GtkWidget *nom1;
GtkWidget *cin1;
GtkWidget *mdp1;
GtkWidget *mail1;
GtkWidget *adresse1;
GtkWidget *combobox1;
GtkWidget *Jour;

GtkWidget *Annee;
GtkWidget *mois;

GtkWidget *output1;
output1=lookup_widget(objet_graphique,"labelmailmod");

GtkWidget *output2;
output2=lookup_widget(objet_graphique,"labelmod");

nom1=lookup_widget(objet_graphique,"nommod");
cin1=lookup_widget(objet_graphique,"cinmod");
mdp1=lookup_widget(objet_graphique,"mdpmod");
mail1=lookup_widget(objet_graphique,"mailmod");
adresse1=lookup_widget(objet_graphique,"adressemod");
combobox1=lookup_widget(objet_graphique,"comboboxmod");
Jour=lookup_widget(objet_graphique,"spinbuttonmod");
Annee=lookup_widget(objet_graphique,"spinbuttonmod1");
strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(nom1)));
strcpy(s.cin,gtk_entry_get_text(GTK_ENTRY(cin1)));
strcpy(s.mdp,gtk_entry_get_text(GTK_ENTRY(mdp1)));
strcpy(s.mail,gtk_entry_get_text(GTK_ENTRY(mail1)));
strcpy(s.adresse,gtk_entry_get_text(GTK_ENTRY(adresse1)));


s.dt.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
s.dt.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));
strcpy(s.dt.mois,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));

if (strstr(s.mail,"@")){
modifier_a(s);
gtk_label_set_text(GTK_LABEL(output2),"compte modifié");
gtk_label_set_text(GTK_LABEL(output1),"   ");}

else if (strstr(s.mail,"@")==0){
gtk_label_set_text(GTK_LABEL(output2),"    ");
gtk_label_set_text(GTK_LABEL(output1),"xxx@xxx.xx");}


}


void
on_buttonvalider_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f ; 
vol v ; 
GtkWidget *dep , *dest ,*ref ,*compagnie ,*jj ,*mm ,*yy,*heu ,*class ,*prix  ;
GtkWidget *gvol ,*ajout ;



dep=lookup_widget(objet_graphique,"entrydepart"); 
dest=lookup_widget(objet_graphique,"entrydestination");
ref=lookup_widget(objet_graphique,"entryreff"); 
compagnie=lookup_widget(objet_graphique,"entrycompagnie");
jj=lookup_widget(objet_graphique,"spinbuttonj"); 
mm=lookup_widget(objet_graphique,"spinbuttonm");
yy=lookup_widget(objet_graphique,"spinbuttony"); 
 
heu=lookup_widget(objet_graphique,"entryheuredepart");
class=lookup_widget(objet_graphique,"comboboxclass"); 
prix=lookup_widget(objet_graphique,"entryprixvol"); 

strcpy(v.depart,gtk_entry_get_text(GTK_ENTRY(dep)));
strcpy(v.destination,gtk_entry_get_text(GTK_ENTRY(dest)));
strcpy(v.ref,gtk_entry_get_text(GTK_ENTRY(ref)));
strcpy(v.compagnie,gtk_entry_get_text(GTK_ENTRY(compagnie)));
v.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jj));
v.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
v.y=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(yy));
strcpy(v.heure,gtk_entry_get_text(GTK_ENTRY(heu)));
strcpy(v.classe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(class)));;
strcpy(v.prix,gtk_entry_get_text(GTK_ENTRY(prix)));

ajoutervol(v) ; 


}


void
on_buttonafficher_clicked              (GtkButton       *objet_graphique,
                                         gpointer         user_data)
{
GtkWidget *gvol,*treeview;

gvol=lookup_widget(objet_graphique,"espace");



treeview=lookup_widget(gvol,"treeviewvol");
affichervol(treeview) ;
}


void
on_buttonSupprimervol_clicked          (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
char ref[200];
GtkWidget *recherche ;

recherche=lookup_widget(objet_graphique,"entryrecherchevol");


strcpy(ref,gtk_entry_get_text(GTK_ENTRY(recherche)));

supprimervol(ref);
}

char ref[30];
void
on_buttonModifiervol_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *gvol ,*modif ,*recherche;

recherche=lookup_widget(objet_graphique,"entryrecherchevol");


modif=create_Modifiervol();
gtk_widget_show(modif);


strcpy(ref,gtk_entry_get_text(GTK_ENTRY(recherche)));
}


void
on_ajouterr_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
heberg1 h;
GtkWidget *spinbutton1r;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2r,*combobox1r,*input6;
GtkWidget *espace;
GtkWidget *input0;
GtkWidget *output,*output1,*output2,*output3,*output4;
char empty[]="\0";

output=lookup_widget(objet,"erreur");
output1=lookup_widget(objet,"erreur1");
output2=lookup_widget(objet,"erreur2");
output3=lookup_widget(objet,"erreur3");
output4=lookup_widget(objet,"msger");
espace=lookup_widget(objet,"espace");
input1=lookup_widget(objet,"id");
input2=lookup_widget(objet,"periode");
input0=lookup_widget(objet,"spinbutton1r");
h.etoiles=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1r));
input3=lookup_widget(objet,"prixnuitee");
combobox2r=lookup_widget(objet,"combobox2r");
combobox1r=lookup_widget(objet,"combobox1r");
input6=lookup_widget(objet,"type_pension");

strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.periode,gtk_entry_get_text(GTK_ENTRY(input2)));
h.etoiles=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixnuitee,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.chambres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2r)));
strcpy(h.nom_hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1r)));
strcpy(h.type_pension,gtk_entry_get_text(GTK_ENTRY(input6)));
if(strcmp(h.id,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}
else if(strcmp(h.periode,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output1),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}
else if(strcmp(h.prixnuitee,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output2),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}
else if(strcmp(h.type_pension,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output3),"Tu dois remplir ce champ");
gtk_label_set_text(GTK_LABEL(output4),"Tu dois remplir tout les champs pour pouvoir ajouter un hébergement");
}

else
{
ajouter_heberg(h);
}
}


void
on_afficherr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;
GtkWidget *treeview1r;


espace=lookup_widget(objet,"espace");


treeview1r=lookup_widget(espace,"treeview1r");

afficher_heberg(treeview1r);
}


void
on_supprimerr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;
char id1[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"id1");
strcpy(id1,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimer_heberg(id1);
}


void
on_modifierr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[3000];
GtkWidget *modifierheb;
modifierheb= create_modifierheb();
gtk_widget_show(modifierheb);
}


void
on_retourr_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;

espace=lookup_widget(objet,"espace");

gtk_widget_destroy(espace);
espace=create_espace();
gtk_widget_show(espace);
}


void
on_FHafficher_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *espace;
GtkWidget *FHtreeview1;
espace=lookup_widget(objet_graphique,"espace");
FHtreeview1=lookup_widget(espace,"FHtreeview1");

afficher_reclamation(FHtreeview1);
}


void
on_FHlirerec_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ReclamationClient rc;

GtkWidget *input ;
GtkWidget *output ;
char cin1[20];
char cin[20];
char text1[1000];
input=lookup_widget(objet_graphique,"FHentrylire") ; 
output=lookup_widget(objet_graphique,"showrec") ;
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(input)));
lire_reclamation(cin1,text1);
gtk_label_set_text(GTK_LABEL(output),text1);
}


void
on_FHsupprimer_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHtreeview1;
GtkWidget *FHwindow2;
GtkWidget *input;
GtkWidget *FHoutputsup;
char cin[50];
char cin1[50];
char FHsortiesup[200];
input=lookup_widget(objet_graphique,"FHentrylire");
FHoutputsup=lookup_widget(objet_graphique,"FHsucessuprimer");

strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input)));
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(input)));
supprimer_reclamation(cin);
supprimer_Treclamation(cin);
supprimer_Trep(cin1);
saySuccesSupprimer(FHsortiesup);
gtk_label_set_text(GTK_LABEL(FHoutputsup),FHsortiesup);

}


void
on_repondre_rec_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow4;
FHwindow4=lookup_widget(objet_graphique,"FHwindow4");
FHwindow4 = create_FHwindow4();
gtk_widget_show(FHwindow4);
}


void
on_modifierfr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[3000];
char idd[3000];
heberg1 h1;
GtkWidget *modspinbuttonr;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2r,*combobox1r,*input6;
GtkWidget *modifier;
GtkWidget *input0;
GtkWidget *modcomboboxr;
GtkWidget *modcomboboxhr;
modifier=lookup_widget(objet,"modifier");
input1=lookup_widget(objet,"modid");
input2=lookup_widget(objet,"modperiode");
input0=lookup_widget(objet,"modspinbuttonr");
h1.etoiles=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbuttonr));
input3=lookup_widget(objet,"modprix");
combobox2r=lookup_widget(objet,"modcomboboxr");
combobox1r=lookup_widget(objet,"modcomboboxhr");
input6=lookup_widget(objet,"modpension");

strcpy(h1.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.periode,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.etoiles=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixnuitee,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.chambres,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2r)));
strcpy(h1.nom_hotel,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1r)));
strcpy(h1.type_pension,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier_heberg(h1);
}


void
on_rechercherhebm_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
heberg1 h;
GtkWidget *modifierheb;
GtkWidget *input1,*output1,*output2,*output4,*output5;

char idd[3000];
char modperiode[300];
char modprix[300];
char modpension[300];



output1=lookup_widget(objet,"modid");
output2=lookup_widget(objet,"modperiode");
output4=lookup_widget(objet,"modprix");
output5=lookup_widget(objet,"modpension");
input1=lookup_widget(objet,"idd");
strcpy(idd,gtk_entry_get_text(GTK_ENTRY(input1)));

FILE *f;
	f=fopen("utilisateurR.txt","r");
	if(f!=NULL)
{
while(fscanf(f,"%s %s %d %s %s %s %s  \n",h.id,h.periode,&h.etoiles,h.prixnuitee,h.chambres,h.nom_hotel,h.type_pension)!=EOF)
{
	if (strcmp(h.id,idd)==0)
{
gtk_entry_set_text (GTK_ENTRY (output1),h.id);
gtk_entry_set_text (GTK_ENTRY (output2),h.periode);
gtk_entry_set_text (GTK_ENTRY (output4),h.prixnuitee);
gtk_entry_set_text (GTK_ENTRY (output5),h.type_pension);
}
}

}
fclose(f);

}


void
on_ajouter_rep_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input5,*input4;

GtkWidget *FHwindow4;
GtkWidget *output1;

char cin[100];
char rep[100];

FHwindow4=lookup_widget(objet_graphique,"FHwindow4");
input5=lookup_widget(objet_graphique,"NDentrycinrep");

input4=lookup_widget(objet_graphique,"NDentryrep");

strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(rep,gtk_entry_get_text(GTK_ENTRY(input4)));

ajouter_reponse(cin,rep);
output1=lookup_widget(objet_graphique,"NDaffichereponse");
gtk_label_set_text(GTK_LABEL(output1),"votre réponse a été envoyer avec succés");
}


void
on_buttonvalidermodi_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
vole vv ;
GtkWidget *nprix ,*heure ,*date;
GtkWidget *gvol ,*modif ;

modif=lookup_widget(objet_graphique,"Modifervol");
/*gvol=create_gestionvol();
gtk_widget_show(gvol);
gtk_widget_hide(modif);*/

date=lookup_widget(objet_graphique,"entrynouveldate");
heure=lookup_widget(objet_graphique,"entrynheure");
nprix=lookup_widget(objet_graphique,"entrynprix");

strcpy(vv.nouveldate,gtk_entry_get_text(GTK_ENTRY(date)));
strcpy(vv.nheure,gtk_entry_get_text(GTK_ENTRY(heure)));
strcpy(vv.newprix,gtk_entry_get_text(GTK_ENTRY(nprix)));
modifiervol(ref,vv);}


void
on_consulter_rep_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow5;
FHwindow5=lookup_widget(objet_graphique,"FHwindow5");
FHwindow5= create_FHwindow5();
gtk_widget_show(FHwindow5);
}


void
on_FHmodifier_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *FHwindow3;
FHwindow3=lookup_widget(objet_graphique,"FHwindow3");
FHwindow3 = create_FHwindow3 ();
  gtk_widget_show (FHwindow3);
}


void
on_FHenvoyer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Jour; // spinbutton pour le choix du jour
GtkWidget *Mois; // spinbutton pour le choix du mois
GtkWidget *Annee; // spinbutton pour le choix de l'annee
GtkWidget *Combobox1; // combobox pour le choix de l'objet
GtkWidget *input3 ; //id
GtkWidget *input4 ; //text
GtkWidget *window1;
GtkWidget *output;

// associer les objets avec des variables

input3 = lookup_widget(objet_graphique, "FHentrycin") ;
input4 = lookup_widget(objet_graphique, "FHentrytext") ;
Jour=lookup_widget(objet_graphique, "FHjour");
Mois=lookup_widget(objet_graphique, "FHmois");
Annee=lookup_widget(objet_graphique, "FHannee");
Combobox1=lookup_widget(objet_graphique, "FHcombobox1");
output=lookup_widget(objet_graphique,"FHsuccessajout");


char cin[20];
char objet[30];
char text[1000];
char FHsortie1[200];
Date dt_rec;
ReclamationClient rc;
/* récuperer les valeurs des entrée en utilisant la fonction gtk_entry_get_text qui retourne la chaine choisie par l'utilisateur */

strcpy(rc.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(rc.text,gtk_entry_get_text(GTK_ENTRY(input4)));


/* récuperer les valeurs des spins buttons en utilisant la fonction gtk_spin_button_get_value_as_int qui retourne l'entier choisie par l'utilisateur */

rc.dt_rec.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
rc.dt_rec.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
rc.dt_rec.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));

/* recuperer les valeurs des comboboxs en utilisant la fonction gtk_combo_box_get_active_text qui retourne la chaine de caractere choisie par l'utilisateur */

strcpy(rc.objet,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
ajouter_reclamation(rc);
saySuccesAjout(FHsortie1);
gtk_label_set_text(GTK_LABEL(output),FHsortie1);


}


void
on_buttonmodifierclients_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10;
//GtkWidget *welcome,*windowmodifierclients;
char nom[100];
char prenom[1000];
char sexe[100];
int j;
int m;
int a;
char pays[100];
char adresse[100];
char cin[100];
char motdepasse[100];
input1=lookup_widget(objet,"entrynom10");
input2=lookup_widget(objet,"entrynom100");
input3=lookup_widget(objet,"combobox333");
input4=lookup_widget(objet,"jour10");
input5=lookup_widget(objet,"mois10");
input6=lookup_widget(objet,"annee10");
input7=lookup_widget(objet,"combobox444");
input8=lookup_widget(objet,"entryadresse10");
input9=lookup_widget(objet,"entrycin10");
input10=lookup_widget(objet,"entrymotdepasse10");
strcpy(nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
strcpy(pays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));
strcpy(adresse,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(cin,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(motdepasse,gtk_entry_get_text(GTK_ENTRY(input10)));

modifier_clients(nom,prenom,pays,j,m,a,sexe,adresse,cin,motdepasse);
modifier_users(cin,motdepasse);


/*windowmodifierclients=lookup_widget(objet,"windowmodifierclients");
gtk_widget_destroy(windowmodifierclients);
welcome=create_windowacceuil();
gtk_widget_show(welcome)
*/

}


void
on_meconnecter_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *welcome;
GtkWidget *espace;
GtkWidget *admin;
GtkWidget *espace_client;
GtkWidget *input1;
GtkWidget *input2;
GtkWidget *output;
char id[100];
char mdp[100];
int x;
input1=lookup_widget(objet,"entrycinyy");
input2=lookup_widget(objet,"entrypasswordyy");
output=lookup_widget(objet,"atenterr");
strcpy(id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(input2)));
x=verifier(id,mdp);
if (x==-1){
gtk_label_set_text(GTK_LABEL(output),"compte non trouvé");
}
if (x==1)
{
welcome=lookup_widget(objet,"welcome");

gtk_widget_destroy(welcome);

espace_client=create_espace_client();
gtk_widget_show(espace_client);
}
if (x==3){
welcome=lookup_widget(objet,"welcome");

gtk_widget_destroy(welcome);

admin=create_admin();
gtk_widget_show(admin);
}
if (x==2){
welcome=lookup_widget(objet,"welcome");

gtk_widget_destroy(welcome);

espace=create_espace();
gtk_widget_show(espace);
}

}


void
on_buttoninscriptiony_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;
char motdepasse1[100];

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input13;
GtkWidget *output;
GtkWidget *output1;
GtkWidget *output2;
GtkWidget *output3;
GtkWidget *output4;
GtkWidget *output5;
char empty[]="\0";

GtkWidget *windowfelecitations;

output5=lookup_widget(objet,"erreur5y");
output4=lookup_widget(objet,"erreur4y");
output3=lookup_widget(objet,"erreur3y");
output2=lookup_widget(objet,"erreur2y");
output1=lookup_widget(objet,"erreur1y");
output=lookup_widget(objet,"erreury");
input1=lookup_widget(objet,"entrynomy");
input2=lookup_widget(objet,"entryprenomy");
input3=lookup_widget(objet,"combobox1y");
input4=lookup_widget(objet,"joury");
input5=lookup_widget(objet,"moisy");
input6=lookup_widget(objet,"anneey");
input7=lookup_widget(objet,"combobox2y");
input8=lookup_widget(objet,"entryadressey");
input9=lookup_widget(objet,"entryciny");
input13=lookup_widget(objet,"entryemaily");
input10=lookup_widget(objet,"entrymotdepassey");
input11=lookup_widget(objet,"entrymotdepasse1y");
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(c.pays,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));
c.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input4));
c.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
c.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
strcpy(c.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));
strcpy(c.adresse,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(c.motdepasse,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(motdepasse1,gtk_entry_get_text(GTK_ENTRY(input11)));
if(strcmp(c.nom,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output1),"Ce champ est obligatoire.");
}
else if(strcmp(c.prenom,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output2),"Ce champ est obligatoire.");
}
else if(strcmp(c.adresse,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output3),"Ce champ est obligatoire.");
}
else if(strcmp(c.cin,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output4),"Ce champ est obligatoire.");
}
else if(strcmp(c.motdepasse,empty)==0)
{
gtk_label_set_text(GTK_LABEL(output5),"Ce champ est obligatoire.");
}
else if(strcmp(motdepasse1,c.motdepasse)!=0)
{
gtk_label_set_text(GTK_LABEL(output),"Les mots de passe saisis ne sont pas identiques.");
}

else
{
inscription(c);
windowfelecitations=create_windowfelecitations();
gtk_widget_show(windowfelecitations);
}
}


void
on_FHconfirmer_modification_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *Jour; // spinbutton pour le choix du jour
GtkWidget *Mois; // spinbutton pour le choix du mois
GtkWidget *Annee; // spinbutton pour le choix de l'annee
GtkWidget *Combobox1; // combobox pour le choix de l'objet

GtkWidget *input3 ; //id
GtkWidget *input4 ; //text
GtkWidget *window1;
GtkWidget *output;

char cin[20];
char objet[30];
char text[1000];
char FHsortie2[200];
Date dt_rec;
ReclamationClient rc;

// associer les objets avec des variables

input3 = lookup_widget(objet_graphique, "FHentrycinmod") ;
input4 = lookup_widget(objet_graphique, "FHentrytextmod") ;
Jour=lookup_widget(objet_graphique, "FHjourmod");
Mois=lookup_widget(objet_graphique, "FHmoismod");
Annee=lookup_widget(objet_graphique, "FHanneemod");
Combobox1=lookup_widget(objet_graphique, "FHcombobox1mod");
output=lookup_widget(objet_graphique,"FHsuccessmodifier");


/* récuperer les valeurs des entrée en utilisant la fonction gtk_entry_get_text qui retourne la chaine choisie par l'utilisateur */

strcpy(rc.cin,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(rc.text,gtk_entry_get_text(GTK_ENTRY(input4)));


/* récuperer les valeurs des spins buttons en utilisant la fonction gtk_spin_button_get_value_as_int qui retourne l'entier choisie par l'utilisateur */

rc.dt_rec.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Jour));
rc.dt_rec.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Mois));
rc.dt_rec.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON (Annee));

/* recuperer les valeurs des comboboxs en utilisant la fonction gtk_combo_box_get_active_text qui retourne la chaine de caractere choisie par l'utilisateur */

strcpy(rc.objet,gtk_combo_box_get_active_text(GTK_COMBO_BOX(Combobox1)));
modifier_reclamation(rc);
modifier_text(rc);
saySuccesModifier(FHsortie2);
gtk_label_set_text(GTK_LABEL(output),FHsortie2);

}


void
on_lire_rep1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *input ;
GtkWidget *output ;

char cin1[20];
char cin[20];
char rep1[1000];

input=lookup_widget(objet_graphique,"NDentrycinvoir") ; 
output=lookup_widget(objet_graphique,"show_rep") ;
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(input)));

lire_reponse(cin1,rep1);

gtk_label_set_text(GTK_LABEL(output),rep1);
}


void
on_deconnexionadmin_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *welcome;
GtkWidget *admin;
admin=lookup_widget(objet,"admin");

gtk_widget_destroy(admin);
welcome=create_welcome();
gtk_widget_show(welcome);
}


void
on_voirdispov_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dep , *desti;
char depart[50][50];
char destination[50][50]; 
int n=0,i; 
dep=lookup_widget(objet,"combobox1vam");
desti=lookup_widget(objet,"combobox2vam");

n=remplir(depart,destination);
 if (n!=0) 
  {
    for (i=0 ;i<n ;i++)
       {
         gtk_combo_box_append_text (GTK_COMBO_BOX (dep),_(depart[i]));
          gtk_combo_box_append_text (GTK_COMBO_BOX (desti),_(destination[i]));
         
       }
  }

}


void
on_ajouterv_clicked                    (GtkWidget       *objet,
                                   gpointer   user_data)
{
heberg h;
GtkWidget *spinbutton1vam;
GtkWidget *nombreper;
GtkWidget *input1,*input2,*input3,*combobox2vam,*combobox1vam,*input6;
GtkWidget *espace;
GtkWidget *input0;

espace=lookup_widget(objet,"espace");
input1=lookup_widget(objet,"idvam");
input2=lookup_widget(objet,"datevam");
input0=lookup_widget(objet,"spinbutton1vam");
h.nombreper=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1vam));
input3=lookup_widget(objet,"prixvolam");
combobox2vam=lookup_widget(objet,"combobox2vam");
combobox1vam=lookup_widget(objet,"combobox1vam");
input6=lookup_widget(objet,"classvam");

strcpy(h.idvam,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.datevam,gtk_entry_get_text(GTK_ENTRY(input2)));
h.nombreper=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixvolam,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.villed,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2vam)));
strcpy(h.destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1vam)));
strcpy(h.classvam,gtk_entry_get_text(GTK_ENTRY(input6)));
ajouterv_heberg(h);
}


void
on_afficherv_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;
GtkWidget *treeview1vam;


espace=lookup_widget(objet,"espace");


treeview1vam=lookup_widget(espace,"treeview1vam");

afficherv_heberg(treeview1vam);
}


void
on_supprimerv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;
char id1vam[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"id1vam");
strcpy(id1vam,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimerv_heberg(id1vam);
}


void
on_modifierv_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1[3000];
GtkWidget *modifierrvol;
modifierrvol= create_modifierrvol();
gtk_widget_show(modifierrvol);
}


void
on_retourv_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;

espace=lookup_widget(objet,"espace");

gtk_widget_destroy(espace);
espace=create_espace();
gtk_widget_show(espace);
}


void
on_buttondispo_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *hot , *cham;
char hotel[50][50];
char chambre[50][50]; 
int n=0,i; 
hot=lookup_widget(objet,"combobox1am");
cham=lookup_widget(objet,"combobox2am");

n=remplir(hotel,chambre);
 if (n!=0) 
  {
    for (i=0 ;i<n ;i++)
       {
         gtk_combo_box_append_text (GTK_COMBO_BOX (hot),_(hotel[i]));
          gtk_combo_box_append_text (GTK_COMBO_BOX (cham),_(chambre[i]));
         
       }
  }
}


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
rheberg h;
GtkWidget *spinbutton1;
GtkWidget *etoiles;
GtkWidget *input1,*input2,*input3,*combobox2,*combobox1,*input6;
GtkWidget *espace;
GtkWidget *input0;

espace=lookup_widget(objet,"espaceam");
input1=lookup_widget(objet,"idam");
input2=lookup_widget(objet,"periodeam");
input0=lookup_widget(objet,"spinbutton1am");
h.etoilesam=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1));
input3=lookup_widget(objet,"prixnuiteeam");
combobox2=lookup_widget(objet,"combobox2am");
combobox1=lookup_widget(objet,"combobox1am");
input6=lookup_widget(objet,"type_pensionam");

strcpy(h.idam,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.periodeam,gtk_entry_get_text(GTK_ENTRY(input2)));
h.etoilesam=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixnuiteeam,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.chambresam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2)));
strcpy(h.nom_hotelam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
strcpy(h.type_pensionam,gtk_entry_get_text(GTK_ENTRY(input6)));
ajouter_rheberg(h);

}


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;
GtkWidget *treeview1am;


espace=lookup_widget(objet,"espace");


treeview1am=lookup_widget(espace,"treeview1am");

afficher_rheberg(treeview1am);
}


void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espaceam;
char idam1[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"idam1");
strcpy(idam1,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimer_rheberg(idam1);
}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
char idam1[3000];
GtkWidget *modifierrheb;
modifierrheb= create_modifierrheb();
gtk_widget_show(modifierrheb);
}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;

espace=lookup_widget(objet,"espace");

gtk_widget_destroy(espace);
espace=create_espace();
gtk_widget_show(espace);
}


void
on_deconnexionemploye_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *welcome;
GtkWidget *espace;
espace=lookup_widget(objet,"espace");

gtk_widget_destroy(espace);
welcome=create_welcome();
gtk_widget_show(welcome);
}


void
on_voirdispov2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dep , *desti;
char depart[50][50];
char destination[50][50]; 
int n=0,i; 
dep=lookup_widget(objet,"combobox1vam2");
desti=lookup_widget(objet,"combobox2vam2");

n=remplir3(depart,destination);
 if (n!=0) 
  {
    for (i=0 ;i<n ;i++)
       {
         gtk_combo_box_append_text (GTK_COMBO_BOX (dep),_(depart[i]));
          gtk_combo_box_append_text (GTK_COMBO_BOX (desti),_(destination[i]));
         
       }
  }
}


void
on_ajouterv2_clicked                   (GtkWidget       *objet,
                                   gpointer   user_data)
{
heberg2 h;
GtkWidget *spinbutton1vam2;
GtkWidget *nombreper2;
GtkWidget *input1,*input2,*input3,*combobox2vam2,*combobox1vam2,*input6;
GtkWidget *espace;
GtkWidget *input0;

espace=lookup_widget(objet,"espace_client");
input1=lookup_widget(objet,"idvam2");
input2=lookup_widget(objet,"datevam2");
input0=lookup_widget(objet,"spinbutton1vam2");
h.nombreper2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1vam2));
input3=lookup_widget(objet,"prixvolam2");
combobox2vam2=lookup_widget(objet,"combobox2vam2");
combobox1vam2=lookup_widget(objet,"combobox1vam2");
input6=lookup_widget(objet,"classvam2");

strcpy(h.idvam2,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.datevam2,gtk_entry_get_text(GTK_ENTRY(input2)));
h.nombreper2=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixvolam2,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.villed2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2vam2)));
strcpy(h.destination2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1vam2)));
strcpy(h.classvam2,gtk_entry_get_text(GTK_ENTRY(input6)));
ajouterv2_heberg2(h);
}


void
on_afficherv2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace_client;
GtkWidget *treeview1vam2;


espace_client=lookup_widget(objet,"espace_client");


treeview1vam2=lookup_widget(espace_client,"treeview1vam2");

afficher2_heberg2(treeview1vam2);
}


void
on_supprimerv2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace;
char id1vam2[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"id1vam2");
strcpy(id1vam2,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimer2_heberg2(id1vam2);
}


void
on_modifierv2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id12[3000];
GtkWidget *modifierrvol1;
modifierrvol1= create_modifierrvol1();
gtk_widget_show(modifierrvol1);

}


void
on_retourv2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace_client;

espace_client=lookup_widget(objet,"espace_client");

gtk_widget_destroy(espace_client);
espace_client=create_espace_client();
gtk_widget_show(espace_client);
}


void
on_voirdispo1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *hot , *cham;
char hotel[50][50];
char chambre[50][50]; 
int n=0,i; 
hot=lookup_widget(objet,"combobox1am1");
cham=lookup_widget(objet,"combobox2am1");

n=remplir(hotel,chambre);
 if (n!=0) 
  {
    for (i=0 ;i<n ;i++)
       {
         gtk_combo_box_append_text (GTK_COMBO_BOX (hot),_(hotel[i]));
          gtk_combo_box_append_text (GTK_COMBO_BOX (cham),_(chambre[i]));
         
       }
  }

}


void
on_ajouter1_clicked                    (GtkWidget       *objet,
                                   gpointer   user_data)
{
rheberg1 h;
GtkWidget *spinbutton1am1;
GtkWidget *etoilesam1;
GtkWidget *input1,*input2,*input3,*combobox2am1,*combobox1am1,*input6;
GtkWidget *espace;
GtkWidget *input0;

espace=lookup_widget(objet,"espace_client");
input1=lookup_widget(objet,"idam1");
input2=lookup_widget(objet,"periodeam1");
input0=lookup_widget(objet,"spinbutton1am1");
h.etoilesam1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (spinbutton1am1));
input3=lookup_widget(objet,"entry3");
combobox2am1=lookup_widget(objet,"combobox2am1");
combobox1am1=lookup_widget(objet,"combobox1am1");
input6=lookup_widget(objet,"type_pension1");

strcpy(h.idam1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.periodeam1,gtk_entry_get_text(GTK_ENTRY(input2)));
h.etoilesam1=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h.prixnuiteeam1,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.chambresam1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2am1)));
strcpy(h.nom_hotelam1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1am1)));
strcpy(h.type_pensionam1,gtk_entry_get_text(GTK_ENTRY(input6)));
ajouter1_rheberg1(h);

}


void
on_afficher1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace_client;
GtkWidget *treeview1am1;


espace_client=lookup_widget(objet,"espace_client");


treeview1am1=lookup_widget(espace_client,"treeview1am1");

afficher1_rheberg(treeview1am1);
}


void
on_supprimer1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espaceam;
char idam11[2000];
GtkWidget *input7;
input7=lookup_widget(objet,"idam11");
strcpy(idam11,gtk_entry_get_text(GTK_ENTRY(input7)));
supprimer1_rheberg(idam11);
}


void
on_modifier1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char idam11[3000];
GtkWidget *modifierrheb1;
modifierrheb1= create_modifierrheb1();
gtk_widget_show(modifierrheb1);

}


void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *espace_client;

espace_client=lookup_widget(objet,"espace_client");

gtk_widget_destroy(espace_client);
espace_client=create_espace_client();
gtk_widget_show(espace_client);

}


void
on_deconnexionclient_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *welcome;
GtkWidget *client;
client=lookup_widget(objet,"espace_client");

gtk_widget_destroy(client);
welcome=create_welcome();
gtk_widget_show(welcome);
}


void
on_modifierf_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
char idam1[3000];
rheberg h1;
GtkWidget *modspinbuttonam;
GtkWidget *etoilesam;
GtkWidget *input1,*input2,*input3,*combobox2am,*combobox1am,*input6;
GtkWidget *modifier;
GtkWidget *input0;
GtkWidget *modcomboboxam;
GtkWidget *modcomboboxham;

modifier=lookup_widget(objet,"modifieram");
input1=lookup_widget(objet,"modidam");
input2=lookup_widget(objet,"modperiodeam");
input0=lookup_widget(objet,"modspinbuttonam");
h1.etoilesam=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbuttonam));
input3=lookup_widget(objet,"modprixam");
combobox2am=lookup_widget(objet,"modcomboboxam");
combobox1am=lookup_widget(objet,"modcomboboxham");
input6=lookup_widget(objet,"modpensionam");

strcpy(h1.idam,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.periodeam,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.etoilesam=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixnuiteeam,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.chambresam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2am)));
strcpy(h1.nom_hotelam,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1am)));
strcpy(h1.type_pensionam,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier_rheberg(h1);

}


void
on_modifierfvam_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1vam[3000];
heberg h1;
GtkWidget *modspinbuttonvam;
GtkWidget *nombreper;
GtkWidget *input1,*input2,*input3,*combobox2vam,*combobox1vam,*input6;
GtkWidget *modifier;
GtkWidget *input0;
GtkWidget *modcomboboxvam;
GtkWidget *modcomboboxhvam;

modifier=lookup_widget(objet,"modifier");
input1=lookup_widget(objet,"modidvam");
input2=lookup_widget(objet,"moddatevam");
input0=lookup_widget(objet,"modspinbuttonvam");
h1.nombreper=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbuttonvam));
input3=lookup_widget(objet,"modprixvolam");
combobox2vam=lookup_widget(objet,"modcomboboxvam");
combobox1vam=lookup_widget(objet,"modcomboboxhvam");
input6=lookup_widget(objet,"modclassvam");

strcpy(h1.idvam,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.datevam,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.nombreper=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixvolam,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.villed,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2vam)));
strcpy(h1.destination,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1vam)));
strcpy(h1.classvam,gtk_entry_get_text(GTK_ENTRY(input6)));
modifierv_heberg(h1);

}


void
on_modifierf1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
char idam1[3000];
rheberg1 h1;
GtkWidget *modspinbuttonam1;
GtkWidget *etoilesam1;
GtkWidget *input1,*input2,*input3,*combobox2am1,*combobox1am1,*input6;
GtkWidget *modifier;
GtkWidget *input0;
GtkWidget *modcomboboxam1;
GtkWidget *modcomboboxham1;

modifier=lookup_widget(objet,"modifieram");
input1=lookup_widget(objet,"modidam1");
input2=lookup_widget(objet,"modperiodeam1");
input0=lookup_widget(objet,"modspinbuttonam1");
h1.etoilesam1=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbuttonam1));
input3=lookup_widget(objet,"modprixam1");
combobox2am1=lookup_widget(objet,"modcomboboxam1");
combobox1am1=lookup_widget(objet,"modcomboboxham1");
input6=lookup_widget(objet,"modpensionam1");

strcpy(h1.idam1,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.periodeam1,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.etoilesam1=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixnuiteeam1,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.chambresam1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2am1)));
strcpy(h1.nom_hotelam1,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1am1)));
strcpy(h1.type_pensionam1,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier1_rheberg1(h1);
}


void
on_modifierfvam2_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id1vam2[3000];
heberg2 h1;
GtkWidget *modspinbuttonvam2;
GtkWidget *nombreper2;
GtkWidget *input1,*input2,*input3,*combobox2vam2,*combobox1vam2,*input6;
GtkWidget *modifierrvol1;
GtkWidget *input0;
GtkWidget *modcomboboxvam2;
GtkWidget *modcomboboxhvam2;

modifierrvol1=lookup_widget(objet,"modifierrvol1");
input1=lookup_widget(objet,"modidvam2");
input2=lookup_widget(objet,"moddatevam2");
input0=lookup_widget(objet,"modspinbuttonvam2");
h1.nombreper2=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON (modspinbuttonvam2));
input3=lookup_widget(objet,"modprixvolam2");
combobox2vam2=lookup_widget(objet,"modcomboboxvam2");
combobox1vam2=lookup_widget(objet,"modcomboboxhvam2");
input6=lookup_widget(objet,"modclassvam2");

strcpy(h1.idvam2,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h1.datevam2,gtk_entry_get_text(GTK_ENTRY(input2)));
h1.nombreper2=gtk_spin_button_get_value_as_int(GTK_ENTRY(input0));
strcpy(h1.prixvolam2,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h1.villed2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox2vam2)));
strcpy(h1.destination2,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1vam2)));
strcpy(h1.classvam2,gtk_entry_get_text(GTK_ENTRY(input6)));
modifier2_heberg2(h1);}

