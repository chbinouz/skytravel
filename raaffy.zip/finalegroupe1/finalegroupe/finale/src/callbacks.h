#include <gtk/gtk.h>


void
on_buttonajouteradmin_clicked          (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_actualiseradmin_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimeradmin_clicked              (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_modifieradmin_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_actualiserverif_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_suppverif_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifieradminfen_clicked            (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvalider_clicked               (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonafficher_clicked              (GtkButton       *objet_graphique,
                                         gpointer         user_data);

void
on_buttonSupprimervol_clicked          (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonModifiervol_clicked           (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_ajouterr_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficherr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierr_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourr_clicked                     (GtkWidget      *objet,
                                        gpointer         user_data);

void
on_FHafficher_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHlirerec_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHsupprimer_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_repondre_rec_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_modifierfr_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_rechercherhebm_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_rep_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonvalidermodi_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_consulter_rep_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHmodifier_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_FHenvoyer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_buttonmodifierclients_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_meconnecter_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttoninscriptiony_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_FHconfirmer_modification_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_lire_rep1_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_deconnexionadmin_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_voirdispov_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouterv_clicked                    (GtkWidget       *objet,
                                   gpointer   user_data);

void
on_afficherv_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerv_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierv_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourv_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttondispo_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deconnexionemploye_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_voirdispov2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouterv2_clicked                   (GtkWidget       *objet,
                                   gpointer   user_data);

void
on_afficherv2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimerv2_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierv2_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retourv2_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_voirdispo1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_ajouter1_clicked                    (GtkWidget       *objet,
                                   gpointer   user_data);

void
on_afficher1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier1_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_deconnexionclient_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierf_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierfvam_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierf1_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifierfvam2_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);
