#include <stdio.h>
#include <string.h>
#include "fonctions1.h"
#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>
enum
{
	IDAM1,
	PERIODEAM1,
	ETOILESAM1,
	PRIXNUITEEAM1,
	CHAMBRESAM1,
	NOM_HOTELAM1,
	TYPE_PENSIONAM1,
	COLUMNS
};

void ajouter1_rheberg1(rheberg1 h)
{

 FILE *f;
 f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","a+");
 if(f!=NULL)
 {
 fprintf(f,"%s %s %d %s %s %s %s  \n",h.idam1,h.periodeam1,h.etoilesam1,h.prixnuiteeam1,h.chambresam1,h.nom_hotelam1,h.type_pensionam1);
 fclose(f);
 }

}


void afficher1_rheberg(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char idam1 [3000];
char periodeam1 [30];
int  etoilesam1;
char prixnuiteeam1 [30];
char chambresam1 [30];
char nom_hotelam1 [30];
char type_pensionam1 [3000];
store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("ID",renderer,"text",IDAM1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Periode",renderer,"text",PERIODEAM1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Etoiles",renderer,"text",ETOILESAM1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Prix d'une nuitee",renderer,"text",PRIXNUITEEAM1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Chambres",renderer,"text",CHAMBRESAM1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nom hotel",renderer,"text",NOM_HOTELAM1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Type pension",renderer,"text",TYPE_PENSIONAM1,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}
	
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","a+");
		while(fscanf(f,"%s %s %d %s %s %s %s  \n",idam1,periodeam1,&etoilesam1,prixnuiteeam1,chambresam1,nom_hotelam1,type_pensionam1)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,IDAM1,idam1,PERIODEAM1,periodeam1,ETOILESAM1,etoilesam1,PRIXNUITEEAM1,prixnuiteeam1,CHAMBRESAM1,chambresam1,NOM_HOTELAM1,nom_hotelam1,TYPE_PENSIONAM1,type_pensionam1,-1);
		}
	   fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	
}
void supprimer1_rheberg(char idam11[]){
rheberg1 h;
FILE *f_h;
FILE *f_h1;

int r;
int n;
f_h=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","r");
f_h1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb1.txt","w");
if (f_h!=NULL){
    if(f_h1!=NULL){
while(fscanf(f_h,"%s %s %d %s %s %s %s",h.idam1,h.periodeam1,&h.etoilesam1,h.prixnuiteeam1,h.chambresam1,h.nom_hotelam1,h.type_pensionam1)!=EOF ) {
    if(strcmp(idam11,h.idam1)!=0){
        fprintf(f_h1,"%s %s %d %s %s %s %s \n",h.idam1,h.periodeam1,h.etoilesam1,h.prixnuiteeam1,h.chambresam1,h.nom_hotelam1,h.type_pensionam1);
        r=1;
    }
}
    }
    fclose(f_h1);
}

fclose(f_h);
if (r){
	remove ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt");
	rename ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb1.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt");
	}

}
void modifier1_rheberg1(rheberg1 h){
int n=0;
char idam11[3000];

char modidam1[2000];
char modperiodeam1[20];
int  modetoilesam1;
char modprixam1[30];
char modchambresam1[30];
char modnomam1[20];
char modpensionam1[1000];


    FILE *f_rheberg;
    FILE *f_rheberg1;
f_rheberg=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt","r");
f_rheberg1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb2.txt","w");
if(f_rheberg!=NULL){
    if(f_rheberg1!=NULL){
while (fscanf(f_rheberg,"%s %s %d %s %s %s %s",modidam1,modperiodeam1,&modetoilesam1,modprixam1,modchambresam1,modnomam1,modpensionam1,&n)!=EOF){
            if  (strcmp(h.idam1,modidam1)==0){
 fprintf(f_rheberg1,"%s %s %d %s %s %s %s \n",h.idam1,h.periodeam1,h.etoilesam1,h.prixnuiteeam1,h.chambresam1,h.nom_hotelam1,h.type_pensionam1,n);
            }
            else {
   fprintf(f_rheberg1,"%s %s %d %s %s %s %s  \n",modidam1,modperiodeam1,modetoilesam1,modprixam1,modchambresam1,modnomam1,modpensionam1,n);
            }
        }
    }
}
fclose(f_rheberg1);
fclose(f_rheberg);
remove("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb1.txt");
rename("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb2.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/reservationheb.txt");
}



int remplir1(char hotel[][50] , char chambre[][50]) 
{

rheberg1 h ; 

int c=0 ; 


FILE *f ; 
f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %d %s %s %s %s \n",h.idam1,&h.etoilesam1,h.prixnuiteeam1,h.chambresam1,h.nom_hotelam1,h.type_pensionam1)!=EOF)
{

strcpy(hotel[c],h.nom_hotelam1) ;
strcpy(chambre[c],h.chambresam1) ; 
c++ ;
} 
}

fclose(f); 
return c ; 

}


