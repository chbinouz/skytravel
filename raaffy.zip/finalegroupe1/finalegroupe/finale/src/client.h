#include<gtk/gtk.h>
#include<string.h>
typedef struct
{
int jour;
int mois;
int annee;
}dates;

typedef struct
{
char nom[100];
char prenom[100];
dates d;
char adresse[100];
char cin[100];
char pays[100];
char sexe[100];
char motdepasse[100];
}client;

void modifier_clients(char nom[100],char prenom[1000], char pays[100],int jour,int mois,int annee,char sexe[100],char adresse[100],char cin[100], char motdepasse[100]);
void modifier_users(char cin[], char motdepasse[]);
void inscription(client a);
void supprimer(char cin1[30]);
int verifierF (char password[30]);
void supprimer1(char cin1[30]);
int verifier (char password[30],char login[30]);
void supprimer3(char cin1[30],char passwd[30]);
void afficher_client(GtkWidget *liste);

