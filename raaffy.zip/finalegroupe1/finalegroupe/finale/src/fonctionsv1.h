#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>

typedef struct
{
char idvam2[2000];
char datevam2[20];
int nombreper2;
char prixvolam2[30];
char villed2[30];
char destination2[20];
char classvam2[1000];

}heberg2;

void ajouterv2_heberg(heberg2 h);
void afficherv2_heberg(GtkWidget *liste);
void supprimerv2_heberg(char id1[]);
void modifierv2_heberg(heberg2 h);
int remplir3(char depart[][50] , char destination[][50]);
