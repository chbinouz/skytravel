#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>

typedef struct
{
char idam1[2000];
char periodeam1[20];
int etoilesam1;
char prixnuiteeam1[30];
char chambresam1[30];
char nom_hotelam1[20];
char type_pensionam1[1000];

}rheberg1;

void ajouter1_rheberg1(rheberg1 h);
void afficher1_rheberg(GtkWidget *liste);
void supprimer1_rheberg(char idam1[]);
void modifier1_rheberg(rheberg1 h);
int remplir(char hotelam[][50] , char chambream[][50]) ; 
