#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>

typedef struct
{
char idvam[2000];
char datevam[20];
int nombreper;
char prixvolam[30];
char villed[30];
char destination[20];
char classvam[1000];

}heberg;

void ajouterv_heberg(heberg h);
void afficherv_heberg(GtkWidget *liste);
void supprimerv_heberg(char id1[]);
void modifierv_heberg(heberg h);
int remplir(char depart[][50] , char destination[][50]);
