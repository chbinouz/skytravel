#include <stdio.h>
#include <string.h>
#include "fonctionsv1.h"
#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>
enum
{
	IDVAM2,
	DATEVAM2,
	NOMBREPER2,
	PRIXVOLAM2,
	VILLED2,
	DESTINATION2,
	CLASSVAM2,
	COLUMNS
};

void ajouterv2_heberg2(heberg2 h)
{

 FILE *f;
 f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt","a+");
 if(f!=NULL)
 {
 fprintf(f,"%s %s %d %s %s %s %s  \n",h.idvam2,h.datevam2,h.nombreper2,h.prixvolam2,h.villed2,h.destination2,h.classvam2);
 fclose(f);
 }

}

void afficher2_heberg2(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char idvam2 [3000];
char datevam2 [30];
int  nombreper2;
char prixvolam2 [30];
char villed2 [30];
char destination2 [30];
char classvam2 [3000];
store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",IDVAM2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",DATEVAM2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nombre de personne",renderer,"text",NOMBREPER2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Prix vol",renderer,"text",PRIXVOLAM2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Destination",renderer,"text",VILLED2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Ville de départ",renderer,"text",DESTINATION2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("clas",renderer,"text",CLASSVAM2,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}
	
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	
		while(fscanf(f,"%s %s %d %s %s %s %s  \n",idvam2,datevam2,&nombreper2,prixvolam2,villed2,destination2,classvam2)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,IDVAM2,idvam2,DATEVAM2,datevam2,NOMBREPER2,nombreper2,PRIXVOLAM2,prixvolam2,VILLED2,villed2,DESTINATION2,destination2,CLASSVAM2,classvam2,-1);
		}
	   fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	

}
void supprimer2_heberg2(char id1vam2[]){
heberg2 h;
FILE *f_h;
FILE *f_h1;

int r;
int n;
f_h=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt","r");
f_h1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur1.txt","w");
if (f_h!=NULL){
    if(f_h1!=NULL){
while(fscanf(f_h,"%s %s %d %s %s %s %s",h.idvam2,h.datevam2,&h.nombreper2,h.prixvolam2,h.villed2,h.destination2,h.classvam2)!=EOF ) {
    if(strcmp(id1vam2,h.idvam2)!=0){
        fprintf(f_h1,"%s %s %d %s %s %s %s \n",h.idvam2,h.datevam2,h.nombreper2,h.prixvolam2,h.villed2,h.destination2,h.classvam2);
        r=1;
    }
}
    }
    fclose(f_h1);
}

fclose(f_h);
if (r){
	remove ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt");
	rename ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur1.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt");
	}

}
void modifier2_heberg2(heberg2 h){
int n=0;
char id1vam2[3000];

char modidvam2[2000];
char moddatevam2[20];
int  modnombreper2;
char modprixvolam2[30];
char modvilled2[30];
char moddestination2[20];
char modclassvam2[1000];


    FILE *f_heberg;
    FILE *f_heberg1;
f_heberg=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt","r");
f_heberg1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt","w");
if(f_heberg!=NULL){
    if(f_heberg1!=NULL){
while (fscanf(f_heberg,"%s %s %d %s %s %s %s",modidvam2,moddatevam2,&modnombreper2,modprixvolam2,modvilled2,moddestination2,modclassvam2,&n)!=EOF){
            if  (strcmp(h.idvam2,modidvam2)==0){
 fprintf(f_heberg1,"%s %s %d %s %s %s %s \n",h.idvam2,h.datevam2,h.nombreper2,h.prixvolam2,h.villed2,h.destination2,h.classvam2,n);
            }
            else {
   fprintf(f_heberg1,"%s %s %d %s %s %s %s  \n",modidvam2,moddatevam2,modnombreper2,modprixvolam2,modvilled2,moddestination2,modclassvam2,n);
            }
        }
    }
}
fclose(f_heberg1);
fclose(f_heberg);
remove("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt");
rename("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur.txt");
}

int remplir3(char depart[][50] , char destination[][50]) 
{

heberg2 h ; 

int c=0 ; 


FILE *f ; 
f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/vol.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %d %s %s %s %s \n",h.idvam2,h.datevam2,&h.nombreper2,h.prixvolam2,h.villed2,h.destination2,h.classvam2)!=EOF)
{

strcpy(depart[c],h.villed2) ;
strcpy(destination[c],h.destination2) ; 
c++ ;
} 
}

fclose(f); 
return c ; 

}






