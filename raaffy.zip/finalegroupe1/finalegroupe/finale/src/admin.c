  #include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"admin.h"
#include <gtk/gtk.h>

void ajouter_admin(admin ajo)
{
int n=2;
FILE * f_admin;
FILE * f1_admin;
f_admin=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt","a+");
if(f_admin!=NULL){
    fprintf(f_admin,"%s %s %s %d %d/%s/%d %s %s \n",ajo.nom,ajo.cin,ajo.mdp,n,ajo.dt.jour,ajo.dt.mois,ajo.dt.annee,ajo.mail,ajo.adresse);
}
fclose(f_admin);
f1_admin=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/users.txt","a+");
if(f_admin!=NULL){
    fprintf(f_admin,"%s %s %d \n",ajo.cin,ajo.mdp,n);
}
fclose(f1_admin);
}
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
enum
{
	CIN,
	NOM,
	MDP,
	V,
	DATE,
	MAIL,
	ADRESSE,
	COLUMNS
};
void afficher_ad(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter  iter;
GtkListStore *store;


char nom[30];
char cin [30];
char mdp [30];
char date[30];
char mail [30];
char adresse [30];
int v;
store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste); 
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mdp",renderer,"text",MDP,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("v",renderer,"text",V,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mail",renderer,"text",MAIL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",ADRESSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
		while(fscanf(f,"%s %s %s %d %s %s %s \n",nom,cin,mdp,&v,date,mail,adresse)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,NOM,nom,CIN,cin,MDP,mdp,V,v,DATE,date,MAIL,mail,ADRESSE,adresse,-1);
		}
fclose(f);
}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);

}
////////////////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////////////////

/*
void chercher_ad(char cin1[]){
    admin mod1;
int n;
char dat[30];
    FILE * f_admin;
f_admin=fopen("employés.txt","r");
if (f_admin!=NULL) {
    while (fscanf(f_admin,"%s %s %s %d %s %s %s %s",mod1.nom,mod1.cin,mod1.mdp,&n,dat,mod1.mail,mod1.adresse)!=EOF){
        fscanf(f_admin,"%s %s",mod1.nom,mod1.cin);
        if (strcmp(mod1.cin,cin1)==0){
            printf("%s de cin: %s",mod1.nom,cin1);
            break;

        }
        else {
            printf("identifiant cherchée non trouvée\n");

            break;
        }
    }
}
}
*/
void modifier_a(admin mod){
int n=0;

admin mod1;
char dat[30]; 
    FILE * f_admin;
    FILE *f_admin1;
f_admin=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt","r");
f_admin1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé2.txt","w");
if(f_admin!=NULL){
    if(f_admin1!=NULL){
while (fscanf(f_admin,"%s %s %s %d %s %s %s",mod1.nom,mod1.cin,mod1.mdp,&n,dat,mod1.mail,mod1.adresse)!=EOF){
            if  (strcmp(mod.cin,mod1.cin)!=0){
 fprintf(f_admin1,"%s %s %s %d %s %s %s \n",mod1.nom,mod1.cin,mod1.mdp,n,dat,mod1.mail,mod1.adresse);
            }
            else {
   fprintf(f_admin1,"%s %s %s %d %d/%s/%d %s %s \n",mod.nom,mod.cin,mod.mdp,n,mod.dt.jour,mod.dt.mois,mod.dt.annee,mod.mail,mod.adresse);
            }
        }
    }
}
fclose(f_admin1);
fclose(f_admin);
remove("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt");
rename("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé2.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt");
}
/*
void afficher_admin(){

char chaine[1000] = "";
FILE * f_aff=NULL;
f_aff= fopen ("employés.txt","r");
if (f_aff != NULL)
    {
        do
        {
            fgets(chaine, 1000, f_aff);
        printf("%s", chaine);

        }while (fgets(chaine, 1000, f_aff) != NULL); // On affiche la chaîne

        fclose(f_aff);

}
}


*/
int supprimer_adm(char cin[]){
admin sup;
FILE *f_sup;
FILE *f_sup1;
int r,x;
int n;
char dat[30];
f_sup=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt","r");
f_sup1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé1.txt","w");
if (f_sup!=NULL){
    if(f_sup1!=NULL){
while(fscanf(f_sup,"%s %s %s %d %s %s %s",sup.nom,sup.cin,sup.mdp,&n,dat,sup.mail,sup.adresse)!=EOF ) {
    if(strcmp(cin,sup.cin)!=0){

        fprintf(f_sup1,"%s %s %s %d %s %s %s\n",sup.nom,sup.cin,sup.mdp,n,dat,sup.mail,sup.adresse);
        r=1;
x=0;
    }
else x=1;
}
fclose(f_sup1);
    }
  fclose(f_sup);  

}


if (r){
	remove ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt");
	rename ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé1.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/employé.txt");
	}
return x;
}

