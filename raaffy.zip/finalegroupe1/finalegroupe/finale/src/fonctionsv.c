#include <stdio.h>
#include <string.h>
#include "fonctionsv.h"
#include <gtk/gtk.h>
#include <gtk/gtkclist.h>
#include <gdk/gdkkeysyms.h>

enum
{
	IDVAM,
	DATEVAM,
	NOMBREPER,
	PRIXVOLAM,
	VILLED,
	DESTINATION,
	CLASSVAM,
	COLUMNS
};

void ajouterv_heberg(heberg h)
{

 FILE *f;
 f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt","a+");
 if(f!=NULL)
 {
 fprintf(f,"%s %s %d %s %s %s %s  \n",h.idvam,h.datevam,h.nombreper,h.prixvolam,h.villed,h.destination,h.classvam);
 fclose(f);
 }

}

void afficherv_heberg(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char idvam [3000];
char datevam [30];
int  nombreper;
char prixvolam [30];
char villed [30];
char destination [30];
char classvam [3000];
store =NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",IDVAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Date",renderer,"text",DATEVAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW (liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Nombre de personne",renderer,"text",NOMBREPER,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Prix vol",renderer,"text",PRIXVOLAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Destination",renderer,"text",VILLED,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Ville de départ",renderer,"text",DESTINATION,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("clas",renderer,"text",CLASSVAM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);}
	
	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

	f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt","r");

	if(f==NULL)
	{
		return;
	}
	else
	
	{ 
	
		while(fscanf(f,"%s %s %d %s %s %s %s  \n",idvam,datevam,&nombreper,prixvolam,villed,destination,classvam)!=EOF)
		{
			gtk_list_store_append(store,&iter);
			gtk_list_store_set(store,&iter,IDVAM,idvam,DATEVAM,datevam,NOMBREPER,nombreper,PRIXVOLAM,prixvolam,VILLED,villed,DESTINATION,destination,CLASSVAM,classvam,-1);
		}
	   fclose(f);}
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
	g_object_unref(store);
	

}
void supprimerv_heberg(char id1vam[]){
heberg h;
FILE *f_h;
FILE *f_h1;

int r;
int n;
f_h=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt","r");
f_h1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur21.txt","w");
if (f_h!=NULL){
    if(f_h1!=NULL){
while(fscanf(f_h,"%s %s %d %s %s %s %s",h.idvam,h.datevam,&h.nombreper,h.prixvolam,h.villed,h.destination,h.classvam)!=EOF ) {
    if(strcmp(id1vam,h.idvam)!=0){
        fprintf(f_h1,"%s %s %d %s %s %s %s \n",h.idvam,h.datevam,h.nombreper,h.prixvolam,h.villed,h.destination,h.classvam);
        r=1;
    }
}
    }
    fclose(f_h1);
}

fclose(f_h);
if (r){
	remove ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt");
	rename ("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur21.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt");
	}

}
void modifierv_heberg(heberg h){
int n=0;
char id1vam[3000];

char modidvam[2000];
char moddatevam[20];
int  modnombreper;
char modprixvolam[30];
char modvilled[30];
char moddestination[20];
char modclassvam[1000];


    FILE *f_heberg;
    FILE *f_heberg1;
f_heberg=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt","r");
f_heberg1=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur22.txt","w");
if(f_heberg!=NULL){
    if(f_heberg1!=NULL){
while (fscanf(f_heberg,"%s %s %d %s %s %s %s",modidvam,moddatevam,&modnombreper,modprixvolam,modvilled,moddestination,modclassvam,&n)!=EOF){
            if  (strcmp(h.idvam,modidvam)==0){
 fprintf(f_heberg1,"%s %s %d %s %s %s %s \n",h.idvam,h.datevam,h.nombreper,h.prixvolam,h.villed,h.destination,h.classvam,n);
            }
            else {
   fprintf(f_heberg1,"%s %s %d %s %s %s %s  \n",modidvam,moddatevam,modnombreper,modprixvolam,modvilled,moddestination,modclassvam,n);
            }
        }
    }
fclose(f_heberg1);
}
fclose(f_heberg);
remove("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt");
rename("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur22.txt","/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/utilisateur2.txt");
}

int remplir2(char depart[][50] , char destination[][50]) 
{

heberg h ; 

int c=0 ; 


FILE *f ; 
f=fopen("/home/chbinou/Desktop/finalegroupe1/finalegroupe/finale/src/vol2.txt","r");
if(f!=NULL)
{
while(fscanf(f,"%s %s %d %s %s %s %s \n",h.idvam,h.datevam,&h.nombreper,h.prixvolam,h.villed,h.destination,h.classvam)!=EOF)
{

strcpy(depart[c],h.villed) ;
strcpy(destination[c],h.destination) ; 
c++ ;
} 
}

fclose(f); 
return c ; 

}






