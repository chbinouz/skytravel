#ifndef ADMIN_H_INCLUDED
#define ADMIN_H_INCLUDED
#include<gtk/gtk.h>
typedef struct date{
int jour;
char mois[30];
int annee;
}date;

typedef struct admin {
char nom[30];
char cin[30];
date dt;
char mail[30];
char adresse[30];
char mdp[30];
}admin;


void ajouter_admin(admin ajo);

void chercher_ad(char cin1[]);

void modifier_a(admin mod);

void afficher_admin();

int supprimer_adm(char cin[]);

void afficher_ad(GtkWidget *liste);
#endif // ADMIN_H_INCLUDED

